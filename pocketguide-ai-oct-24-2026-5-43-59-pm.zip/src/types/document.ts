export type ReadingLevel = 'simple' | 'standard' | 'detailed';

export type DocumentCategory = 
  | 'School & Education'
  | 'Medical & Health'
  | 'Government & Legal'
  | 'Financial & Bills'
  | 'Workplace & HR'
  | 'Manuals & Tech'
  | 'General';

export interface KeyInformationItem {
  id: string;
  label: string;
  value: string;
  category?: 'Person' | 'Organization' | 'Amount' | 'Reference ID' | 'Requirement' | 'Other';
  sourceSnippet?: string;
  isUncertain?: boolean;
}

export interface DocumentDateItem {
  id: string;
  date: string;
  context: string;
  isDeadline: boolean;
  sourceSnippet?: string;
  isUncertain?: boolean;
}

export interface ActionItem {
  id: string;
  title: string;
  description: string;
  completed: boolean;
  priority: 'high' | 'medium' | 'low';
  dueDate?: string;
  sourceSnippet?: string;
}

export interface QAExchange {
  id: string;
  question: string;
  answer: string;
  sourcePassage?: string;
  isFound: boolean;
  timestamp: number;
}

export interface DocumentAnalysis {
  readingLevel: ReadingLevel;
  summary: string;
  keyPoints: string[];
  keyInfo: KeyInformationItem[];
  dates: DocumentDateItem[];
  actions: ActionItem[];
  translatedLanguage?: string;
  translatedSummary?: string;
  isLocalFallback: boolean;
  analyzedAt: number;
}

export interface PocketDocument {
  id: string;
  title: string;
  category: DocumentCategory;
  extractedText: string;
  originalFileName?: string;
  fileType: 'pdf' | 'image' | 'text' | 'sample';
  pageCount?: number;
  previewUrl?: string; // Data URL or object URL for scanned image/page
  ocrConfidence?: number;
  analysis?: DocumentAnalysis;
  qaHistory: QAExchange[];
  createdAt: number;
  updatedAt: number;
}

export interface UserPreferences {
  defaultReadingLevel: ReadingLevel;
  allowExternalAI: boolean;
  speechRate: number;
  preferredVoice?: string;
  highContrast: boolean;
  hasSeenOnboarding: boolean;
}

export interface ServerHealthResponse {
  status: 'ok';
  hasGeminiKey: boolean;
  model: string;
  timestamp: string;
  localFallbackActive: boolean;
}
