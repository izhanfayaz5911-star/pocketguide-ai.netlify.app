import React, { useState } from 'react';
import { 
  Search, 
  Trash2, 
  Edit2, 
  Download, 
  FileText, 
  CheckCircle2, 
  Calendar, 
  ArrowRight, 
  Check, 
  X,
  Plus
} from 'lucide-react';
import { PocketDocument, DocumentCategory } from '../types/document';

interface DocumentLibraryProps {
  documents: PocketDocument[];
  onSelectDocument: (doc: PocketDocument) => void;
  onDeleteDocument: (id: string) => void;
  onRenameDocument: (id: string, newTitle: string) => void;
  onNewScan: () => void;
}

export const DocumentLibrary: React.FC<DocumentLibraryProps> = ({
  documents,
  onSelectDocument,
  onDeleteDocument,
  onRenameDocument,
  onNewScan,
}) => {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [categoryFilter, setCategoryFilter] = useState<string>('All');
  const [sortBy, setSortBy] = useState<'date' | 'title'>('date');
  const [deletingDocId, setDeletingDocId] = useState<string | null>(null);
  const [editingDocId, setEditingDocId] = useState<string | null>(null);
  const [editTitleInput, setEditTitleInput] = useState<string>('');

  const categories = ['All', 'School & Education', 'Medical & Health', 'Financial & Bills', 'Government & Legal', 'Manuals & Tech', 'General'];

  const filteredDocs = documents
    .filter((doc) => {
      const matchSearch =
        doc.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        doc.extractedText.toLowerCase().includes(searchQuery.toLowerCase());
      const matchCat = categoryFilter === 'All' || doc.category === categoryFilter;
      return matchSearch && matchCat;
    })
    .sort((a, b) => {
      if (sortBy === 'title') return a.title.localeCompare(b.title);
      return b.updatedAt - a.updatedAt;
    });

  const handleStartRename = (e: React.MouseEvent, doc: PocketDocument) => {
    e.stopPropagation();
    setEditingDocId(doc.id);
    setEditTitleInput(doc.title);
  };

  const handleSaveRename = (id: string) => {
    if (editTitleInput.trim()) {
      onRenameDocument(id, editTitleInput.trim());
    }
    setEditingDocId(null);
  };

  const handleConfirmDelete = (id: string) => {
    onDeleteDocument(id);
    setDeletingDocId(null);
  };

  const handleExportDoc = (e: React.MouseEvent, doc: PocketDocument) => {
    e.stopPropagation();
    const content = `# ${doc.title}
Category: ${doc.category}
Date: ${new Date(doc.updatedAt).toLocaleDateString()}

## Summary
${doc.analysis?.summary || 'No analysis available.'}

## Key Takeaways
${(doc.analysis?.keyPoints || []).map((p) => `- ${p}`).join('\n')}

## Important Dates
${(doc.analysis?.dates || []).map((d) => `- ${d.date}: ${d.context}`).join('\n')}

## Action Checklist
${(doc.analysis?.actions || []).map((a) => `- [${a.completed ? 'x' : ' '}] ${a.title}`).join('\n')}

## Original Extracted Text
${doc.extractedText}
`;

    const blob = new Blob([content], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${doc.title.replace(/[^a-z0-9]/gi, '_')}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 space-y-6">
      {/* Title & Stats */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            Saved Documents
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            {documents.length} document{documents.length === 1 ? '' : 's'} stored securely in local browser storage.
          </p>
        </div>

        <button
          onClick={onNewScan}
          className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs transition-colors cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Scan Document</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-2xl border border-slate-200/80 p-4 shadow-xs space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          {/* Search field */}
          <div className="relative flex-1 min-w-[260px]">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by title, keywords, or text content..."
              className="w-full pl-9 pr-4 py-2 text-xs rounded-xl border border-slate-200 focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
            />
          </div>

          {/* Sort selector */}
          <div className="flex items-center gap-2 text-xs text-slate-600">
            <span>Sort by:</span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-700 font-medium"
            >
              <option value="date">Recently Updated</option>
              <option value="title">Alphabetical (Title)</option>
            </select>
          </div>
        </div>

        {/* Category Filter Tabs */}
        <div className="flex items-center gap-1 overflow-x-auto pb-1 scrollbar-none">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setCategoryFilter(cat)}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                categoryFilter === cat
                  ? 'bg-blue-50 text-blue-700 font-semibold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/60'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Document Grid / Cards */}
      {filteredDocs.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-2xl border border-dashed border-slate-200 p-8 space-y-3">
          <div className="w-12 h-12 rounded-xl bg-slate-100 flex items-center justify-center text-slate-400 mx-auto">
            <FileText className="w-6 h-6" />
          </div>
          <h3 className="text-base font-semibold text-slate-800">
            {searchQuery || categoryFilter !== 'All' ? 'No matching documents found' : 'No documents saved yet'}
          </h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            {searchQuery
              ? 'Try modifying your search keywords or clear the category filter.'
              : 'Scan your first document, import a PDF, or load one of our realistic sample documents.'}
          </p>
          <button
            onClick={onNewScan}
            className="mt-3 px-4 py-2 text-xs font-semibold text-white bg-blue-600 rounded-lg hover:bg-blue-700 transition-colors"
          >
            Scan Document
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredDocs.map((doc) => {
            const completedTasks = doc.analysis?.actions.filter((a) => a.completed).length || 0;
            const totalTasks = doc.analysis?.actions.length || 0;

            return (
              <div
                key={doc.id}
                onClick={() => onSelectDocument(doc)}
                className="group bg-white rounded-2xl border border-slate-200/80 hover:border-blue-300 p-5 shadow-xs hover:shadow-sm transition-all cursor-pointer flex flex-col justify-between"
              >
                <div className="space-y-3">
                  {/* Category & Date Metadata */}
                  <div className="flex items-center justify-between text-[11px] text-slate-500 font-medium">
                    <span>{doc.category}</span>
                    <span className="font-mono tabular-nums">
                      {new Date(doc.updatedAt).toLocaleDateString()}
                    </span>
                  </div>

                  {/* Title (or Inline Editing Input) */}
                  {editingDocId === doc.id ? (
                    <div className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
                      <input
                        type="text"
                        value={editTitleInput}
                        onChange={(e) => setEditTitleInput(e.target.value)}
                        className="w-full px-2.5 py-1 text-sm font-semibold rounded-lg border border-blue-500 focus:outline-none"
                        autoFocus
                      />
                      <button
                        onClick={() => handleSaveRename(doc.id)}
                        className="p-1 text-blue-600 hover:text-blue-800"
                      >
                        <Check className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => setEditingDocId(null)}
                        className="p-1 text-slate-400 hover:text-slate-600"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ) : (
                    <h3 className="text-base font-bold text-slate-900 group-hover:text-blue-600 transition-colors line-clamp-2 leading-snug">
                      {doc.title}
                    </h3>
                  )}

                  {/* Preview summary snippet */}
                  <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                    {doc.analysis?.summary || doc.extractedText.slice(0, 140)}
                  </p>
                </div>

                <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                  {/* Action items badge/indicator */}
                  <div className="flex items-center gap-1.5 font-mono text-[11px]">
                    <CheckCircle2 className="w-3.5 h-3.5 text-blue-600" />
                    <span className="tabular-nums">
                      {completedTasks}/{totalTasks} tasks
                    </span>
                  </div>

                  {/* Quick Card Controls */}
                  <div className="flex items-center gap-1" onClick={(e) => e.stopPropagation()}>
                    <button
                      onClick={(e) => handleStartRename(e, doc)}
                      className="p-1 text-slate-400 hover:text-slate-600 rounded"
                      title="Rename document"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={(e) => handleExportDoc(e, doc)}
                      className="p-1 text-slate-400 hover:text-slate-600 rounded"
                      title="Export document"
                    >
                      <Download className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => setDeletingDocId(doc.id)}
                      className="p-1 text-slate-400 hover:text-red-600 rounded"
                      title="Delete document"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deletingDocId && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-xl space-y-4">
            <h3 className="text-base font-bold text-slate-900">
              Delete Document?
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Are you sure you want to delete this document and all its action items? This action cannot be undone.
            </p>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setDeletingDocId(null)}
                className="px-4 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 rounded-lg hover:bg-slate-100"
              >
                Cancel
              </button>
              <button
                onClick={() => handleConfirmDelete(deletingDocId)}
                className="px-4 py-2 text-xs font-semibold text-white bg-red-600 hover:bg-red-700 rounded-lg"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
