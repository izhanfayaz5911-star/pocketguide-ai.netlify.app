import React, { useState, useRef, useEffect } from 'react';
import { 
  Upload, 
  Camera, 
  RotateCw, 
  FileText, 
  Check, 
  AlertCircle, 
  Loader2, 
  X, 
  ArrowRight, 
  Sparkles,
  BookOpen,
  RefreshCw
} from 'lucide-react';
import { performImageOCR, extractPDFText, rotateImageDataUrl, OCRProgress } from '../lib/ocr';
import { SAMPLE_DOCUMENTS } from '../lib/sampleDocs';
import { PocketDocument, DocumentCategory } from '../types/document';

interface DocumentScannerProps {
  onDocumentCreated: (doc: PocketDocument) => void;
  onCancel: () => void;
}

export const DocumentScanner: React.FC<DocumentScannerProps> = ({
  onDocumentCreated,
  onCancel,
}) => {
  const [mode, setMode] = useState<'upload' | 'camera' | 'review'>('upload');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const [rotation, setRotation] = useState<number>(0);
  
  // OCR processing states
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [ocrProgress, setOcrProgress] = useState<OCRProgress | null>(null);
  const [extractedText, setExtractedText] = useState<string>('');
  const [ocrConfidence, setOcrConfidence] = useState<number | undefined>(undefined);
  const [pageCount, setPageCount] = useState<number>(1);
  const [documentTitle, setDocumentTitle] = useState<string>('');
  const [documentCategory, setDocumentCategory] = useState<DocumentCategory>('General');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Camera states
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);
  const [hasCameraError, setHasCameraError] = useState<boolean>(false);

  // Stop camera stream on unmount or mode change
  useEffect(() => {
    return () => {
      if (cameraStream) {
        cameraStream.getTracks().forEach((track) => track.stop());
      }
    };
  }, [cameraStream]);

  // Start live camera stream
  const startCamera = async () => {
    setErrorMessage(null);
    setHasCameraError(false);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 1920 }, height: { ideal: 1080 } },
        audio: false,
      });
      setCameraStream(stream);
      setMode('camera');
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err: any) {
      console.warn('Camera access denied or unavailable:', err);
      setHasCameraError(true);
      setErrorMessage('Camera access was denied or is not supported in this browser. Please upload a photo or document instead.');
    }
  };

  const captureCameraPhoto = () => {
    if (!videoRef.current) return;
    const video = videoRef.current;
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth || 1280;
    canvas.height = video.videoHeight || 720;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    const dataUrl = canvas.toDataURL('image/jpeg', 0.92);

    // Stop camera stream
    if (cameraStream) {
      cameraStream.getTracks().forEach((track) => track.stop());
      setCameraStream(null);
    }

    setPreviewImage(dataUrl);
    setDocumentTitle(`Scanned Notice ${new Date().toLocaleDateString()}`);
    runOCR(dataUrl, 'image');
  };

  const handleFileDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processInputFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processInputFile(e.target.files[0]);
    }
  };

  const processInputFile = async (file: File) => {
    setErrorMessage(null);
    setSelectedFile(file);
    const titleCandidate = file.name.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' ');
    setDocumentTitle(titleCandidate);

    if (file.type === 'application/pdf') {
      // PDF processing
      setIsProcessing(true);
      try {
        const result = await extractPDFText(file, (p) => setOcrProgress(p));
        setExtractedText(result.text);
        setPageCount(result.pageCount);
        setOcrConfidence(result.confidence);
        setMode('review');
      } catch (err: any) {
        setErrorMessage(err.message || 'Failed to extract text from PDF');
      } finally {
        setIsProcessing(false);
      }
    } else if (file.type.startsWith('image/')) {
      // Image processing with real OCR
      const reader = new FileReader();
      reader.onload = (event) => {
        const dataUrl = event.target?.result as string;
        setPreviewImage(dataUrl);
        runOCR(dataUrl, 'image');
      };
      reader.readAsDataURL(file);
    } else {
      setErrorMessage('Please upload a PDF document or an image file (PNG, JPG, WebP).');
    }
  };

  const runOCR = async (imageSource: string, type: 'image') => {
    setIsProcessing(true);
    setErrorMessage(null);
    try {
      const result = await performImageOCR(imageSource, (p) => setOcrProgress(p));
      setExtractedText(result.text);
      setOcrConfidence(result.confidence);
      setPageCount(1);
      setMode('review');
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to run OCR on the image. You can type or paste the text manually below.');
      setMode('review');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleRotate = async () => {
    if (!previewImage) return;
    const nextRotation = (rotation + 90) % 360;
    setRotation(nextRotation);
    try {
      const rotated = await rotateImageDataUrl(previewImage, 90);
      setPreviewImage(rotated);
      // Re-run OCR on rotated image
      runOCR(rotated, 'image');
    } catch (e) {
      console.error('Rotation failed', e);
    }
  };

  const handleSelectSample = (sampleId: string) => {
    const sample = SAMPLE_DOCUMENTS.find((s) => s.id === sampleId);
    if (!sample) return;

    setDocumentTitle(sample.title);
    setDocumentCategory(sample.category);
    setExtractedText(sample.extractedText);
    setOcrConfidence(99);
    setPageCount(1);
    setSelectedFile(null);
    setPreviewImage(null);
    setMode('review');
  };

  const handleProceedToAnalysis = () => {
    if (!extractedText.trim()) {
      setErrorMessage('Extracted text cannot be empty. Please scan a document or type the text.');
      return;
    }

    const newDoc: PocketDocument = {
      id: `doc-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      title: documentTitle.trim() || 'Untitled Document',
      category: documentCategory,
      extractedText: extractedText.trim(),
      originalFileName: selectedFile?.name || (previewImage ? 'scanned_document.jpg' : undefined),
      fileType: selectedFile?.type === 'application/pdf' ? 'pdf' : previewImage ? 'image' : 'text',
      pageCount,
      previewUrl: previewImage || undefined,
      ocrConfidence,
      qaHistory: [],
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };

    onDocumentCreated(newDoc);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      {/* Header breadcrumb & title */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
            <span>Documents</span>
            <span aria-hidden="true">·</span>
            <span className="font-medium text-slate-800">
              {mode === 'camera' ? 'Live Camera Capture' : mode === 'review' ? 'Verify & Review Text' : 'Scan or Import'}
            </span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            {mode === 'review' ? 'Review Extracted Document Text' : 'Scan or Upload a Document'}
          </h1>
        </div>

        <button
          onClick={onCancel}
          className="p-2 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition-colors"
          title="Cancel and return to dashboard"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {errorMessage && (
        <div className="mb-6 p-4 rounded-xl bg-red-50 border border-red-200 text-red-800 flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
          <div className="text-sm">
            <p className="font-semibold">Notice</p>
            <p className="text-red-700 mt-0.5">{errorMessage}</p>
          </div>
        </div>
      )}

      {/* MODE 1: Camera capture */}
      {mode === 'camera' && (
        <div className="bg-slate-900 rounded-2xl overflow-hidden shadow-lg p-4 text-white">
          <div className="relative aspect-[4/3] max-h-[500px] w-full bg-black rounded-xl overflow-hidden flex items-center justify-center">
            <video
              ref={(el) => {
                videoRef.current = el;
                if (el && cameraStream && el.srcObject !== cameraStream) {
                  el.srcObject = cameraStream;
                  el.play().catch(() => {});
                }
              }}
              autoPlay
              playsInline
              muted
              className="w-full h-full object-cover"
            />

            {/* Document alignment overlay guides */}
            <div className="absolute inset-8 border-2 border-white/40 border-dashed rounded-lg pointer-events-none flex flex-col justify-between p-3">
              <span className="text-[11px] text-white/70 font-mono tracking-wider bg-black/40 px-2 py-0.5 rounded self-start">
                Align document within frame
              </span>
              <span className="text-[11px] text-white/70 font-mono tracking-wider bg-black/40 px-2 py-0.5 rounded self-end">
                Hold still for clear text
              </span>
            </div>
          </div>

          <div className="flex items-center justify-between mt-4 px-2">
            <button
              onClick={() => {
                if (cameraStream) {
                  cameraStream.getTracks().forEach((t) => t.stop());
                  setCameraStream(null);
                }
                setMode('upload');
              }}
              className="px-4 py-2 text-xs font-medium text-slate-300 hover:text-white transition-colors"
            >
              Cancel Camera
            </button>

            <button
              onClick={captureCameraPhoto}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-blue-600 hover:bg-blue-500 active:scale-95 text-white font-semibold text-sm shadow-md transition-all cursor-pointer"
            >
              <Camera className="w-4 h-4" />
              <span>Capture Page</span>
            </button>

            <div className="w-20" />
          </div>
        </div>
      )}

      {/* MODE 2: Upload Dropzone & Sample Picker */}
      {mode === 'upload' && !isProcessing && (
        <div className="space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Camera button card */}
            <div
              onClick={startCamera}
              className="border-2 border-dashed border-slate-200 hover:border-blue-400 bg-white hover:bg-blue-50/20 rounded-2xl p-6 text-center cursor-pointer transition-all flex flex-col items-center justify-center min-h-[220px] group"
            >
              <div className="w-12 h-12 rounded-xl bg-blue-50 group-hover:bg-blue-100 flex items-center justify-center text-blue-600 mb-3 transition-colors">
                <Camera className="w-6 h-6" />
              </div>
              <h3 className="text-base font-semibold text-slate-900 group-hover:text-blue-700">
                Scan with Camera
              </h3>
              <p className="text-xs text-slate-500 mt-1 max-w-xs">
                Take a photo of a printed letter, notice, prescription, or paperwork using your device camera.
              </p>
              <span className="mt-4 inline-flex items-center gap-1.5 text-xs font-semibold text-blue-600">
                Open Camera <ArrowRight className="w-3.5 h-3.5" />
              </span>
            </div>

            {/* File dropzone card */}
            <div
              onDragOver={(e) => e.preventDefault()}
              onDrop={handleFileDrop}
              className="border-2 border-dashed border-slate-200 hover:border-indigo-400 bg-white hover:bg-indigo-50/20 rounded-2xl p-6 text-center cursor-pointer transition-all flex flex-col items-center justify-center min-h-[220px] relative group"
            >
              <input
                type="file"
                accept="application/pdf,image/png,image/jpeg,image/webp"
                onChange={handleFileInputChange}
                className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                title="Choose file"
              />
              <div className="w-12 h-12 rounded-xl bg-indigo-50 group-hover:bg-indigo-100 flex items-center justify-center text-indigo-600 mb-3 transition-colors">
                <Upload className="w-6 h-6" />
              </div>
              <h3 className="text-base font-semibold text-slate-900 group-hover:text-indigo-700">
                Upload PDF or Photo
              </h3>
              <p className="text-xs text-slate-500 mt-1 max-w-xs">
                Drop your PDF or image here, or browse files on your computer or phone.
              </p>
              <span className="mt-4 inline-flex items-center gap-1.5 text-xs font-semibold text-indigo-600">
                Browse Files <ArrowRight className="w-3.5 h-3.5" />
              </span>
            </div>
          </div>

          {/* Quick test sample selector */}
          <div className="bg-white rounded-2xl border border-slate-200/80 p-6 shadow-xs">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-slate-600" />
                <h3 className="text-sm font-bold text-slate-900">
                  Try a Realistic Test Document (1-Click)
                </h3>
              </div>
              <span className="text-xs text-slate-400">Zero setup required</span>
            </div>
            <p className="text-xs text-slate-500 mb-4">
              Test how PocketGuide AI extracts key dates, converts notices into action checklists, and answers questions using these realistic fictional documents:
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {SAMPLE_DOCUMENTS.map((sample) => (
                <button
                  key={sample.id}
                  onClick={() => handleSelectSample(sample.id)}
                  className="text-left p-3.5 rounded-xl border border-slate-200 hover:border-blue-400 hover:bg-blue-50/30 transition-all group cursor-pointer"
                >
                  <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                    <span className="font-medium text-slate-600">{sample.category}</span>
                    <span className="text-[11px] font-mono text-blue-600 group-hover:underline">Load Doc</span>
                  </div>
                  <h4 className="text-xs font-semibold text-slate-900 group-hover:text-blue-700 line-clamp-1">
                    {sample.title}
                  </h4>
                  <p className="text-[11px] text-slate-500 mt-1 line-clamp-2">
                    {sample.summaryPreview}
                  </p>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Progress state during OCR or PDF parsing */}
      {isProcessing && (
        <div className="bg-white rounded-2xl border border-slate-200/80 p-8 shadow-xs text-center space-y-4">
          <div className="w-14 h-14 rounded-2xl bg-blue-50 flex items-center justify-center text-blue-600 mx-auto">
            <Loader2 className="w-7 h-7 animate-spin" />
          </div>
          <div>
            <h3 className="text-base font-semibold text-slate-900">
              Extracting Document Text
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              {ocrProgress?.status || 'Analyzing typography and optical characters...'}
            </p>
          </div>

          {ocrProgress && (
            <div className="max-w-xs mx-auto space-y-1">
              <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                <div
                  className="h-full bg-blue-600 transition-all duration-300 rounded-full"
                  style={{ width: `${Math.round(ocrProgress.progress * 100)}%` }}
                />
              </div>
              <div className="flex justify-between text-[11px] font-mono text-slate-400">
                <span>OCR Progress</span>
                <span className="tabular-nums">{Math.round(ocrProgress.progress * 100)}%</span>
              </div>
            </div>
          )}
        </div>
      )}

      {/* MODE 3: Review & Edit Extracted Text */}
      {mode === 'review' && !isProcessing && (
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-6 space-y-6">
          {/* Document metadata controls */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="md:col-span-2 space-y-1">
              <label className="text-xs font-semibold text-slate-700">Document Title</label>
              <input
                type="text"
                value={documentTitle}
                onChange={(e) => setDocumentTitle(e.target.value)}
                placeholder="e.g. Oakridge Excursion Slip"
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700">Category</label>
              <select
                value={documentCategory}
                onChange={(e) => setDocumentCategory(e.target.value as DocumentCategory)}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 bg-white"
              >
                <option value="School & Education">School & Education</option>
                <option value="Medical & Health">Medical & Health</option>
                <option value="Financial & Bills">Financial & Bills</option>
                <option value="Government & Legal">Government & Legal</option>
                <option value="Workplace & HR">Workplace & HR</option>
                <option value="Manuals & Tech">Manuals & Tech</option>
                <option value="General">General</option>
              </select>
            </div>
          </div>

          {/* Image preview & rotation if image was captured/uploaded */}
          {previewImage && (
            <div className="border border-slate-200 rounded-xl p-3 bg-slate-50 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <img
                  src={previewImage}
                  alt="Scanned page preview"
                  className="w-12 h-12 object-cover rounded-lg border border-slate-200"
                />
                <div className="text-xs">
                  <p className="font-semibold text-slate-800">Scanned Document Image</p>
                  <p className="text-slate-500 font-mono text-[11px]">
                    OCR Confidence: <span className="tabular-nums font-semibold text-blue-600">{ocrConfidence || 95}%</span>
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleRotate}
                  className="px-2.5 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-100 flex items-center gap-1 transition-colors"
                  title="Rotate image 90 degrees and re-run OCR"
                >
                  <RotateCw className="w-3.5 h-3.5" />
                  <span>Rotate 90°</span>
                </button>
              </div>
            </div>
          )}

          {/* Text Editor area */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
                <FileText className="w-4 h-4 text-blue-600" />
                <span>Extracted Document Text (Editable)</span>
              </label>

              <div className="flex items-center gap-3 text-xs text-slate-400 font-mono">
                <span>{extractedText.split(/\s+/).filter(Boolean).length} words</span>
                <span aria-hidden="true">·</span>
                <span>{extractedText.split('\n').length} lines</span>
              </div>
            </div>

            <p className="text-xs text-slate-500">
              Review the extracted text below. You can correct typos or add details before running the AI explanation and checklist generator.
            </p>

            <textarea
              value={extractedText}
              onChange={(e) => setExtractedText(e.target.value)}
              rows={12}
              className="w-full p-3.5 text-sm font-mono text-slate-800 rounded-xl border border-slate-200 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 leading-relaxed bg-slate-50/50"
              placeholder="Document text will appear here..."
            />
          </div>

          {/* Action buttons */}
          <div className="flex items-center justify-between pt-2 border-t border-slate-100">
            <button
              onClick={() => setMode('upload')}
              className="px-4 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 rounded-lg hover:bg-slate-100 transition-colors"
            >
              Scan Another File
            </button>

            <button
              onClick={handleProceedToAnalysis}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-semibold text-sm shadow-xs transition-colors cursor-pointer"
            >
              <Sparkles className="w-4 h-4" />
              <span>Generate Plain-Language Explanation</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
