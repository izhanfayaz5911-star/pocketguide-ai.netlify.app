import React from 'react';
import { Camera, Sparkles, CheckSquare, X, ArrowRight, Shield } from 'lucide-react';

interface OnboardingModalProps {
  isOpen: boolean;
  onClose: () => void;
  onStartScan: () => void;
  onTrySample: () => void;
}

export const OnboardingModal: React.FC<OnboardingModalProps> = ({
  isOpen,
  onClose,
  onStartScan,
  onTrySample,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-lg w-full p-8 shadow-2xl space-y-6 relative">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header with App Logo */}
        <div className="text-center space-y-2">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-blue-600 to-indigo-700 flex items-center justify-center text-white shadow-md mx-auto mb-3">
            <svg
              className="w-7 h-7 text-white"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2.2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a2.5 2.5 0 0 1-2.5-2.5z" />
              <path d="M8 7h6" />
              <path d="M8 11h4" />
              <polygon points="17 12 18.2 14.5 21 15 19 17 19.5 20 17 18.5 14.5 20 15 17 13 15 15.8 14.5 17 12" fill="currentColor" stroke="none" />
            </svg>
          </div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900">
            Welcome to PocketGuide AI
          </h2>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Turn confusing paperwork, school slips, and technical instructions into crystal-clear actionable steps.
          </p>
        </div>

        {/* 3 Value Pillars */}
        <div className="space-y-3.5">
          <div className="flex items-start gap-3.5 p-3 rounded-2xl bg-slate-50/80 border border-slate-100">
            <div className="w-9 h-9 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center shrink-0">
              <Camera className="w-4 h-4" />
            </div>
            <div className="text-xs space-y-0.5">
              <h4 className="font-semibold text-slate-900">1. Real On-Device OCR</h4>
              <p className="text-slate-500 leading-relaxed">
                Scan with your phone or computer camera, or upload PDFs. Image text recognition runs locally in your browser.
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3.5 p-3 rounded-2xl bg-slate-50/80 border border-slate-100">
            <div className="w-9 h-9 rounded-xl bg-indigo-100 text-indigo-700 flex items-center justify-center shrink-0">
              <Sparkles className="w-4 h-4" />
            </div>
            <div className="text-xs space-y-0.5">
              <h4 className="font-semibold text-slate-900">2. Plain-English Synthesis</h4>
              <p className="text-slate-500 leading-relaxed">
                Translates complicated legal, medical, or administrative jargon into 5th-grade simple or standard reading levels.
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3.5 p-3 rounded-2xl bg-slate-50/80 border border-slate-100">
            <div className="w-9 h-9 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
              <CheckSquare className="w-4 h-4" />
            </div>
            <div className="text-xs space-y-0.5">
              <h4 className="font-semibold text-slate-900">3. Action Checklists & Audio</h4>
              <p className="text-slate-500 leading-relaxed">
                Auto-generates to-do tasks with verified deadlines, and reads explanations aloud via text-to-speech.
              </p>
            </div>
          </div>
        </div>

        {/* Privacy Note */}
        <div className="flex items-center gap-2 text-[11px] text-slate-500 bg-slate-100/60 p-2.5 rounded-xl">
          <Shield className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>Local-first storage. No account needed. Free & open-source stack.</span>
        </div>

        {/* Buttons */}
        <div className="grid grid-cols-2 gap-3 pt-1">
          <button
            onClick={() => {
              onClose();
              onTrySample();
            }}
            className="px-4 py-2.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors cursor-pointer"
          >
            Try a Sample Doc
          </button>

          <button
            onClick={() => {
              onClose();
              onStartScan();
            }}
            className="inline-flex items-center justify-center gap-1.5 px-4 py-2.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs transition-colors cursor-pointer"
          >
            <span>Scan Document</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

      </div>
    </div>
  );
};
