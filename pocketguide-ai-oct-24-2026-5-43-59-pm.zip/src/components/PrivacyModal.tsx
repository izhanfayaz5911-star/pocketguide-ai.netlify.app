import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Download, 
  Trash2, 
  X, 
  Cpu, 
  Database, 
  Cloud, 
  AlertTriangle, 
  Check 
} from 'lucide-react';
import { UserPreferences } from '../types/document';
import { clearAllData, exportAllDataAsJSON } from '../lib/storage';

interface PrivacyModalProps {
  isOpen: boolean;
  onClose: () => void;
  preferences: UserPreferences;
  onUpdatePreferences: (prefs: UserPreferences) => void;
  onDataReset: () => void;
}

export const PrivacyModal: React.FC<PrivacyModalProps> = ({
  isOpen,
  onClose,
  preferences,
  onUpdatePreferences,
  onDataReset,
}) => {
  const [showConfirmReset, setShowConfirmReset] = useState<boolean>(false);
  const [downloadSuccess, setDownloadSuccess] = useState<boolean>(false);

  if (!isOpen) return null;

  const handleToggleExternalAI = (checked: boolean) => {
    onUpdatePreferences({
      ...preferences,
      allowExternalAI: checked,
    });
  };

  const handleExportBackup = async () => {
    const jsonStr = await exportAllDataAsJSON();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `PocketGuide_Backup_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
    setDownloadSuccess(true);
    setTimeout(() => setDownloadSuccess(false), 2000);
  };

  const handleWipeData = async () => {
    await clearAllData();
    setShowConfirmReset(false);
    onDataReset();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-xl w-full p-6 shadow-2xl space-y-6 max-h-[90vh] overflow-y-auto">
        
        {/* Modal Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-50 flex items-center justify-center text-emerald-600">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">Privacy & Data Architecture</h2>
              <p className="text-xs text-slate-500">Transparent processing disclosure</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Where Processing Occurs Breakdown */}
        <div className="space-y-3">
          <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
            Where Your Data Is Processed
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div className="p-3 rounded-xl border border-slate-200 bg-slate-50/50 space-y-1">
              <div className="flex items-center gap-1.5 text-slate-800 text-xs font-semibold">
                <Cpu className="w-4 h-4 text-blue-600" />
                <span>Camera & OCR</span>
              </div>
              <p className="text-[11px] text-slate-500 leading-tight">
                100% on-device in your browser via WebAssembly (Tesseract.js). Images never leave your computer or phone.
              </p>
            </div>

            <div className="p-3 rounded-xl border border-slate-200 bg-slate-50/50 space-y-1">
              <div className="flex items-center gap-1.5 text-slate-800 text-xs font-semibold">
                <Database className="w-4 h-4 text-emerald-600" />
                <span>Document Storage</span>
              </div>
              <p className="text-[11px] text-slate-500 leading-tight">
                Local-first IndexedDB in your browser storage. Works offline without requiring an account.
              </p>
            </div>

            <div className="p-3 rounded-xl border border-slate-200 bg-slate-50/50 space-y-1">
              <div className="flex items-center gap-1.5 text-slate-800 text-xs font-semibold">
                <Cloud className="w-4 h-4 text-indigo-600" />
                <span>AI Language Model</span>
              </div>
              <p className="text-[11px] text-slate-500 leading-tight">
                Text sent securely to server for Gemini 3.8 Flash analysis. A local deterministic engine is used if offline.
              </p>
            </div>
          </div>
        </div>

        {/* Privacy Consent Controls */}
        <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/80 space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="text-xs font-semibold text-slate-900">
                Allow External Gemini AI Processing
              </h4>
              <p className="text-[11px] text-slate-500 max-w-sm mt-0.5">
                When enabled, document text is sent to the server for Gemini 3.8 Flash plain-English synthesis. When disabled, PocketGuide AI operates exclusively with its local deterministic engine.
              </p>
            </div>

            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={preferences.allowExternalAI}
                onChange={(e) => handleToggleExternalAI(e.target.checked)}
                className="sr-only peer"
              />
              <div className="w-9 h-5 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-blue-600"></div>
            </label>
          </div>
        </div>

        {/* Data Ownership & Export */}
        <div className="space-y-3 pt-2">
          <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
            Data Portability & Deletion
          </h3>

          <div className="flex flex-wrap items-center justify-between gap-3">
            <button
              onClick={handleExportBackup}
              className="px-3.5 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 flex items-center gap-2 transition-colors cursor-pointer"
            >
              {downloadSuccess ? <Check className="w-4 h-4 text-emerald-600" /> : <Download className="w-4 h-4" />}
              <span>{downloadSuccess ? 'Downloaded Backup' : 'Export All Data (JSON)'}</span>
            </button>

            <button
              onClick={() => setShowConfirmReset(true)}
              className="px-3.5 py-2 text-xs font-medium text-red-600 hover:text-red-700 bg-red-50/60 hover:bg-red-50 border border-red-200/80 rounded-xl flex items-center gap-2 transition-colors cursor-pointer"
            >
              <Trash2 className="w-4 h-4" />
              <span>Wipe All Stored Data</span>
            </button>
          </div>
        </div>

        {/* Wipe confirmation modal */}
        {showConfirmReset && (
          <div className="p-4 rounded-xl border border-red-200 bg-red-50 text-red-900 space-y-3">
            <div className="flex items-start gap-2.5">
              <AlertTriangle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
              <div className="text-xs space-y-1">
                <p className="font-bold">Permanently erase all documents and checklists?</p>
                <p className="text-red-700">
                  This will purge all local IndexedDB documents, tasks, and history from your browser.
                </p>
              </div>
            </div>

            <div className="flex justify-end gap-2">
              <button
                onClick={() => setShowConfirmReset(false)}
                className="px-3 py-1.5 text-xs font-medium text-slate-600 hover:text-slate-900"
              >
                Cancel
              </button>
              <button
                onClick={handleWipeData}
                className="px-3 py-1.5 text-xs font-semibold text-white bg-red-600 hover:bg-red-700 rounded-lg"
              >
                Confirm Erase
              </button>
            </div>
          </div>
        )}

        <div className="pt-2 text-center text-[11px] text-slate-400">
          Budget: ₹0 · Free & Open-Source Stack · Zero Third-Party Advertising Trackers
        </div>
      </div>
    </div>
  );
};
