import React from 'react';
import { Sparkles, Shield, Library, FileText, Camera } from 'lucide-react';

interface HeaderProps {
  activeTab: 'dashboard' | 'scanner' | 'library';
  setActiveTab: (tab: 'dashboard' | 'scanner' | 'library') => void;
  onOpenPrivacy: () => void;
  onNewScan: () => void;
  hasGeminiKey: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  onOpenPrivacy,
  onNewScan,
  hasGeminiKey,
}) => {
  return (
    <header className="sticky top-0 z-30 bg-white/90 backdrop-blur-md border-b border-slate-200/80 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
        
        {/* Zone 1: Brand Wordmark with custom vector logo */}
        <button
          onClick={() => setActiveTab('dashboard')}
          className="flex items-center gap-2.5 text-left group focus-visible:ring-2 focus-visible:ring-blue-500 rounded-lg p-1 -ml-1 transition-transform active:scale-98"
        >
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-blue-600 to-indigo-700 flex items-center justify-center text-white shadow-xs">
            {/* Custom PocketGuide AI Vector Icon: Open Document with Guidance Star */}
            <svg
              className="w-5 h-5 text-white"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2.2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a2.5 2.5 0 0 1-2.5-2.5z" />
              <path d="M8 7h6" />
              <path d="M8 11h4" />
              <polygon points="17 12 18.2 14.5 21 15 19 17 19.5 20 17 18.5 14.5 20 15 17 13 15 15.8 14.5 17 12" fill="currentColor" stroke="none" />
            </svg>
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-base font-bold tracking-tight text-slate-900 whitespace-nowrap">
                PocketGuide
              </span>
              <span className="text-xs font-semibold text-blue-600 bg-blue-50 px-1.5 py-0.2 rounded-md">
                AI
              </span>
            </div>
            <p className="text-[11px] text-slate-500 leading-none hidden sm:block">
              Clear document explanations
            </p>
          </div>
        </button>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden md:flex items-center gap-1 text-sm font-medium text-slate-600" aria-label="Main Navigation">
          <button
            onClick={() => setActiveTab('dashboard')}
            className={`px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
              activeTab === 'dashboard'
                ? 'text-blue-700 bg-blue-50/80 font-semibold'
                : 'hover:text-slate-900 hover:bg-slate-100/60'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>Dashboard</span>
          </button>

          <button
            onClick={() => setActiveTab('scanner')}
            className={`px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
              activeTab === 'scanner'
                ? 'text-blue-700 bg-blue-50/80 font-semibold'
                : 'hover:text-slate-900 hover:bg-slate-100/60'
            }`}
          >
            <Camera className="w-4 h-4" />
            <span>Scan & Upload</span>
          </button>

          <button
            onClick={() => setActiveTab('library')}
            className={`px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
              activeTab === 'library'
                ? 'text-blue-700 bg-blue-50/80 font-semibold'
                : 'hover:text-slate-900 hover:bg-slate-100/60'
            }`}
          >
            <Library className="w-4 h-4" />
            <span>Documents</span>
          </button>

          <button
            onClick={onOpenPrivacy}
            className="px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 text-slate-500 hover:text-slate-900 hover:bg-slate-100/60"
            title="Privacy and data storage settings"
          >
            <Shield className="w-4 h-4 text-emerald-600" />
            <span>Privacy & Storage</span>
          </button>
        </nav>

        {/* Zone 3: 1 Primary Action + engine status */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="hidden lg:flex items-center gap-1.5 text-xs text-slate-500 bg-slate-100/80 px-2.5 py-1 rounded-md" title={hasGeminiKey ? 'Gemini 3.8 Flash active' : 'Local deterministic engine ready'}>
            <Sparkles className={`w-3.5 h-3.5 ${hasGeminiKey ? 'text-indigo-600' : 'text-slate-400'}`} />
            <span className="font-mono text-[11px]">
              {hasGeminiKey ? 'Gemini AI' : 'Local Engine'}
            </span>
          </div>

          <button
            onClick={onNewScan}
            className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 active:bg-blue-800 rounded-lg shadow-xs transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Camera className="w-4 h-4" />
            <span>New Document</span>
          </button>
        </div>

      </div>
    </header>
  );
};
