import React, { useState, useEffect } from 'react';
import { 
  FileText, 
  Sparkles, 
  Calendar, 
  CheckSquare, 
  HelpCircle, 
  Volume2, 
  VolumeX, 
  Pause, 
  Play, 
  RotateCcw, 
  Languages, 
  Copy, 
  Check, 
  Printer, 
  Share2, 
  AlertCircle, 
  ShieldCheck, 
  ExternalLink,
  ChevronRight,
  Info,
  Loader2,
  Send
} from 'lucide-react';
import { PocketDocument, ReadingLevel, ActionItem, QAExchange } from '../types/document';
import { ChecklistManager } from './ChecklistManager';
import { tts, TTSState } from '../lib/tts';

interface DocumentWorkspaceProps {
  document: PocketDocument;
  onUpdateDocument: (doc: PocketDocument) => void;
  onReanalyze: (doc: PocketDocument, readingLevel: ReadingLevel) => Promise<void>;
  isAnalyzing: boolean;
}

export const DocumentWorkspace: React.FC<DocumentWorkspaceProps> = ({
  document,
  onUpdateDocument,
  onReanalyze,
  isAnalyzing,
}) => {
  const [activeTab, setActiveTab] = useState<
    'summary' | 'keyInfo' | 'dates' | 'checklist' | 'qa' | 'original'
  >('summary');

  const [readingLevel, setReadingLevel] = useState<ReadingLevel>(
    document.analysis?.readingLevel || 'standard'
  );

  // Audio TTS states
  const [ttsState, setTtsState] = useState<TTSState>({
    isPlaying: false,
    isPaused: false,
    currentText: '',
    rate: 1.0,
  });
  const [speechRate, setSpeechRate] = useState<number>(1.0);

  // Translation states
  const [targetLang, setTargetLang] = useState<string>('es');
  const [isTranslating, setIsTranslating] = useState<boolean>(false);
  const [translatedText, setTranslatedText] = useState<string | null>(null);

  // Q&A states
  const [questionInput, setQuestionInput] = useState<string>('');
  const [isAsking, setIsAsking] = useState<boolean>(false);
  const [copiedSummary, setCopiedSummary] = useState<boolean>(false);

  // Original text search
  const [searchQuery, setSearchQuery] = useState<string>('');

  useEffect(() => {
    const unsub = tts.subscribe((state) => {
      setTtsState(state);
    });
    return () => {
      unsub();
      tts.stop();
    };
  }, []);

  const analysis = document.analysis;

  // Handle Reading Level Change
  const handleLevelChange = async (newLevel: ReadingLevel) => {
    setReadingLevel(newLevel);
    await onReanalyze(document, newLevel);
  };

  // Handle Text-to-Speech playback
  const handlePlayTTS = () => {
    if (ttsState.isPaused) {
      tts.resume();
      return;
    }

    let textToRead = '';
    if (activeTab === 'summary') {
      textToRead = `${document.title}. ${analysis?.summary || ''} Key points: ${analysis?.keyPoints.join('. ') || ''}`;
    } else if (activeTab === 'checklist') {
      textToRead = `Action checklist for ${document.title}. ${analysis?.actions.map((a) => `${a.title}. ${a.description}`).join('. ') || ''}`;
    } else if (activeTab === 'dates') {
      textToRead = `Important dates: ${analysis?.dates.map((d) => `${d.date}. ${d.context}`).join('. ') || ''}`;
    } else {
      textToRead = analysis?.summary || document.extractedText.slice(0, 1000);
    }

    tts.speak(textToRead, speechRate);
  };

  const handlePauseTTS = () => {
    tts.pause();
  };

  const handleStopTTS = () => {
    tts.stop();
  };

  const handleRateChange = (newRate: number) => {
    setSpeechRate(newRate);
    if (ttsState.isPlaying) {
      handlePlayTTS();
    }
  };

  // Translate Explanation
  const handleTranslate = async (languageName: string) => {
    if (!analysis?.summary) return;
    setIsTranslating(true);
    try {
      const res = await fetch('/api/ai/translate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: analysis.summary,
          targetLanguage: languageName,
        }),
      });
      const data = await res.json();
      setTranslatedText(data.translatedText);
    } catch (e) {
      console.error('Translation failed:', e);
    } finally {
      setIsTranslating(false);
    }
  };

  // Ask Question
  const handleAskQuestion = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!questionInput.trim() || isAsking) return;

    const q = questionInput.trim();
    setQuestionInput('');
    setIsAsking(true);

    try {
      const res = await fetch('/api/ai/qa', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: document.extractedText,
          question: q,
        }),
      });

      const exchange: QAExchange = await res.json();
      const updatedHistory = [...(document.qaHistory || []), exchange];
      const updatedDoc: PocketDocument = {
        ...document,
        qaHistory: updatedHistory,
      };
      onUpdateDocument(updatedDoc);
    } catch (err) {
      console.error('QA request error:', err);
    } finally {
      setIsAsking(false);
    }
  };

  // Update actions checklist
  const handleUpdateActions = (newActions: ActionItem[]) => {
    if (!analysis) return;
    const updatedDoc: PocketDocument = {
      ...document,
      analysis: {
        ...analysis,
        actions: newActions,
      },
    };
    onUpdateDocument(updatedDoc);
  };

  const handleCopySummary = () => {
    if (!analysis?.summary) return;
    navigator.clipboard.writeText(
      `# ${document.title}\n\nSummary:\n${analysis.summary}\n\nKey Takeaways:\n${analysis.keyPoints.map((p) => `- ${p}`).join('\n')}`
    );
    setCopiedSummary(true);
    setTimeout(() => setCopiedSummary(false), 2000);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 space-y-6">
      {/* Top Document Header */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-6 space-y-4">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="space-y-1 max-w-3xl">
            {/* Zero-Pill unboxed metadata with separators */}
            <div className="flex items-center gap-2 text-xs text-slate-500 font-medium">
              <span>{document.category}</span>
              <span aria-hidden="true">·</span>
              <span>Updated {new Date(document.updatedAt).toLocaleDateString()}</span>
              {document.originalFileName && (
                <>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono text-slate-600 truncate max-w-xs">
                    {document.originalFileName}
                  </span>
                </>
              )}
              {document.ocrConfidence !== undefined && (
                <>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono tabular-nums text-slate-600">
                    {document.ocrConfidence}% OCR confidence
                  </span>
                </>
              )}
            </div>

            <h1 className="text-2xl font-bold tracking-tight text-slate-900 leading-tight">
              {document.title}
            </h1>
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-2 shrink-0 no-print">
            <button
              onClick={handleCopySummary}
              className="px-3 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 flex items-center gap-1.5 transition-colors"
              title="Copy summary and key points"
            >
              {copiedSummary ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedSummary ? 'Copied' : 'Copy'}</span>
            </button>

            <button
              onClick={handlePrint}
              className="px-3 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 flex items-center gap-1.5 transition-colors"
              title="Print formatted document briefing"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print</span>
            </button>
          </div>
        </div>

        {/* Engine Transparency Banner & Disclaimer */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-100 text-xs">
          <div className="flex items-center gap-2">
            <span className="flex items-center gap-1.5 text-slate-600">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>Engine:</span>
              <strong className="font-semibold text-slate-800">
                {analysis?.isLocalFallback ? 'Deterministic Local Fallback Engine' : 'Gemini 3.8 Flash (Server)'}
              </strong>
            </span>
          </div>

          <p className="text-[11px] text-slate-400 italic">
            PocketGuide AI explains text content for everyday clarity; it does not replace qualified legal, medical, or government counsel.
          </p>
        </div>
      </div>

      {/* Audio Read-Aloud Toolbar (Web Speech API) */}
      <div className="bg-slate-900 text-white rounded-xl p-3.5 px-4 flex flex-wrap items-center justify-between gap-4 shadow-sm no-print">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-white">
            <Volume2 className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-xs font-semibold">Listen to Explanation (Text-to-Speech)</h4>
            <p className="text-[11px] text-slate-400">
              {ttsState.isPlaying
                ? ttsState.isPaused
                  ? 'Playback paused'
                  : 'Reading aloud...'
                : 'Listen to plain-language explanation hands-free'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {/* Rate selector */}
          <div className="flex items-center gap-1 text-xs text-slate-300">
            <span className="text-[11px] text-slate-400">Speed:</span>
            {[0.8, 1.0, 1.25, 1.5].map((rate) => (
              <button
                key={rate}
                onClick={() => handleRateChange(rate)}
                className={`px-1.5 py-0.5 rounded text-[11px] font-mono tabular-nums ${
                  speechRate === rate ? 'bg-blue-600 text-white font-bold' : 'hover:bg-slate-800 text-slate-300'
                }`}
              >
                {rate}x
              </button>
            ))}
          </div>

          {/* Audio Controls */}
          {!ttsState.isPlaying ? (
            <button
              onClick={handlePlayTTS}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-xs font-semibold text-white transition-colors cursor-pointer"
            >
              <Play className="w-3.5 h-3.5 fill-white" />
              <span>Read Aloud</span>
            </button>
          ) : (
            <div className="flex items-center gap-1.5">
              {ttsState.isPaused ? (
                <button
                  onClick={handlePlayTTS}
                  className="p-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white transition-colors"
                  title="Resume"
                >
                  <Play className="w-4 h-4 fill-white" />
                </button>
              ) : (
                <button
                  onClick={handlePauseTTS}
                  className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white transition-colors"
                  title="Pause"
                >
                  <Pause className="w-4 h-4" />
                </button>
              )}

              <button
                onClick={handleStopTTS}
                className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
                title="Stop playback"
              >
                <VolumeX className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Reading Level Selector & Section Tabs */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        {/* Top Control Bar: Reading Level + 7 Core Tabs */}
        <div className="border-b border-slate-200 px-4 py-3 flex flex-wrap items-center justify-between gap-4 bg-slate-50/60 no-print">
          
          {/* Reading Level Segmented Control */}
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-slate-700">Reading Level:</span>
            <div className="flex items-center gap-1 p-1 bg-slate-200/70 rounded-lg">
              {(['simple', 'standard', 'detailed'] as ReadingLevel[]).map((level) => (
                <button
                  key={level}
                  onClick={() => handleLevelChange(level)}
                  disabled={isAnalyzing}
                  className={`px-2.5 py-1 text-xs font-medium rounded-md transition-all whitespace-nowrap capitalize ${
                    readingLevel === level
                      ? 'bg-white text-slate-900 shadow-xs font-semibold'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {level}
                </button>
              ))}
            </div>
            {isAnalyzing && (
              <span className="flex items-center gap-1 text-xs text-blue-600">
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                <span>Updating...</span>
              </span>
            )}
          </div>

          {/* Translation selector */}
          <div className="flex items-center gap-2">
            <Languages className="w-4 h-4 text-slate-400" />
            <select
              value={targetLang}
              onChange={(e) => {
                setTargetLang(e.target.value);
                const langLabels: Record<string, string> = {
                  es: 'Spanish',
                  fr: 'French',
                  de: 'German',
                  hi: 'Hindi',
                  zh: 'Mandarin Chinese',
                  ar: 'Arabic',
                  pt: 'Portuguese',
                  ja: 'Japanese',
                  vi: 'Vietnamese',
                };
                handleTranslate(langLabels[e.target.value] || 'Spanish');
              }}
              className="text-xs bg-white border border-slate-200 rounded-lg px-2.5 py-1 text-slate-700 focus:ring-1 focus:ring-blue-500"
            >
              <option value="en">Translate Summary...</option>
              <option value="es">Spanish (Español)</option>
              <option value="fr">French (Français)</option>
              <option value="de">German (Deutsch)</option>
              <option value="hi">Hindi (हिन्दी)</option>
              <option value="zh">Mandarin (中文)</option>
              <option value="ar">Arabic (العربية)</option>
              <option value="pt">Portuguese (Português)</option>
              <option value="ja">Japanese (日本語)</option>
              <option value="vi">Vietnamese (Tiếng Việt)</option>
            </select>
          </div>
        </div>

        {/* 7 Core Workspace Navigation Tabs */}
        <div className="flex border-b border-slate-200 overflow-x-auto no-print scrollbar-none px-4">
          <button
            onClick={() => setActiveTab('summary')}
            className={`py-3.5 px-4 text-xs font-semibold border-b-2 whitespace-nowrap transition-colors flex items-center gap-2 ${
              activeTab === 'summary'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Sparkles className="w-4 h-4" />
            <span>1. Plain Summary</span>
          </button>

          <button
            onClick={() => setActiveTab('keyInfo')}
            className={`py-3.5 px-4 text-xs font-semibold border-b-2 whitespace-nowrap transition-colors flex items-center gap-2 ${
              activeTab === 'keyInfo'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Info className="w-4 h-4" />
            <span>2. Key Information ({analysis?.keyInfo.length || 0})</span>
          </button>

          <button
            onClick={() => setActiveTab('dates')}
            className={`py-3.5 px-4 text-xs font-semibold border-b-2 whitespace-nowrap transition-colors flex items-center gap-2 ${
              activeTab === 'dates'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Calendar className="w-4 h-4" />
            <span>3. Important Dates ({analysis?.dates.length || 0})</span>
          </button>

          <button
            onClick={() => setActiveTab('checklist')}
            className={`py-3.5 px-4 text-xs font-semibold border-b-2 whitespace-nowrap transition-colors flex items-center gap-2 ${
              activeTab === 'checklist'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <CheckSquare className="w-4 h-4" />
            <span>4 & 5. Action Checklist ({analysis?.actions.length || 0})</span>
          </button>

          <button
            onClick={() => setActiveTab('qa')}
            className={`py-3.5 px-4 text-xs font-semibold border-b-2 whitespace-nowrap transition-colors flex items-center gap-2 ${
              activeTab === 'qa'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <HelpCircle className="w-4 h-4" />
            <span>6. Ask Document ({document.qaHistory?.length || 0})</span>
          </button>

          <button
            onClick={() => setActiveTab('original')}
            className={`py-3.5 px-4 text-xs font-semibold border-b-2 whitespace-nowrap transition-colors flex items-center gap-2 ${
              activeTab === 'original'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>7. Source Text</span>
          </button>
        </div>

        {/* Tab Contents Area */}
        <div className="p-6">
          {/* TAB 1: Simple Summary */}
          {activeTab === 'summary' && (
            <div className="space-y-6">
              {translatedText && (
                <div className="p-4 rounded-xl bg-blue-50/60 border border-blue-200">
                  <div className="flex items-center justify-between text-xs text-blue-900 font-semibold mb-1">
                    <span>Translated Summary</span>
                    <button
                      onClick={() => setTranslatedText(null)}
                      className="text-blue-600 hover:underline"
                    >
                      Hide Translation
                    </button>
                  </div>
                  <p className="text-sm text-blue-950 leading-relaxed">{translatedText}</p>
                </div>
              )}

              <div className="prose prose-slate max-w-none">
                <h3 className="text-base font-bold text-slate-900 mb-2">
                  What This Document Means
                </h3>
                <p className="text-sm text-slate-800 leading-relaxed whitespace-pre-line">
                  {analysis?.summary || 'No summary generated yet.'}
                </p>
              </div>

              {/* Key Takeaways */}
              {analysis?.keyPoints && analysis.keyPoints.length > 0 && (
                <div className="space-y-3 pt-4 border-t border-slate-100">
                  <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                    Core Takeaways
                  </h4>
                  <ul className="space-y-2">
                    {analysis.keyPoints.map((point, idx) => (
                      <li key={idx} className="flex items-start gap-2.5 text-xs text-slate-700">
                        <span className="w-1.5 h-1.5 rounded-full bg-blue-600 mt-1.5 shrink-0" />
                        <span className="leading-relaxed">{point}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: Key Information */}
          {activeTab === 'keyInfo' && (
            <div className="space-y-4">
              <p className="text-xs text-slate-500">
                Important names, amounts, reference IDs, and contact points identified in the document:
              </p>

              {(!analysis?.keyInfo || analysis.keyInfo.length === 0) ? (
                <div className="py-8 text-center text-xs text-slate-500">
                  No explicit key values or identifiers detected.
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {analysis.keyInfo.map((info) => (
                    <div
                      key={info.id}
                      className="p-3.5 rounded-xl border border-slate-200/80 bg-slate-50/50 space-y-1.5"
                    >
                      <div className="flex items-center justify-between text-xs text-slate-500">
                        <span className="font-medium">{info.label}</span>
                        {info.category && (
                          <span className="text-[11px] font-mono text-slate-400">
                            {info.category}
                          </span>
                        )}
                      </div>

                      <p className="text-sm font-semibold text-slate-900 break-words">
                        {info.value}
                      </p>

                      {info.sourceSnippet && (
                        <p className="text-[11px] text-slate-400 italic pt-1 border-t border-slate-200/60 line-clamp-2">
                          Source: "{info.sourceSnippet}"
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 3: Important Dates */}
          {activeTab === 'dates' && (
            <div className="space-y-4">
              <p className="text-xs text-slate-500">
                Explicit deadlines, scheduled times, and calendar dates found in the document:
              </p>

              {(!analysis?.dates || analysis.dates.length === 0) ? (
                <div className="py-8 text-center text-xs text-slate-500">
                  No dates or deadlines found in this document.
                </div>
              ) : (
                <div className="space-y-3">
                  {analysis.dates.map((d) => (
                    <div
                      key={d.id}
                      className="p-4 rounded-xl border border-slate-200/80 bg-white hover:border-slate-300 transition-colors flex items-start justify-between gap-4 shadow-2xs"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <Calendar className="w-4 h-4 text-blue-600 shrink-0" />
                          <h4 className="text-sm font-bold text-slate-900 font-mono">
                            {d.date}
                          </h4>
                          {d.isDeadline && (
                            <span className="text-[11px] font-semibold text-amber-700 bg-amber-50 px-2 py-0.5 rounded">
                              Deadline
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-slate-700 leading-relaxed">
                          {d.context}
                        </p>
                        {d.sourceSnippet && (
                          <p className="text-[11px] text-slate-400 italic pt-1">
                            Exact quote: "{d.sourceSnippet}"
                          </p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 4 & 5: Action Checklist */}
          {activeTab === 'checklist' && (
            <ChecklistManager
              actions={analysis?.actions || []}
              onUpdateActions={handleUpdateActions}
              documentTitle={document.title}
            />
          )}

          {/* TAB 6: Grounded Q&A */}
          {activeTab === 'qa' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-sm font-bold text-slate-900">
                  Ask a Question About This Document
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Answers are grounded strictly in the extracted document text. Missing information is never fabricated.
                </p>
              </div>

              {/* Question input */}
              <form onSubmit={handleAskQuestion} className="flex gap-2">
                <input
                  type="text"
                  value={questionInput}
                  onChange={(e) => setQuestionInput(e.target.value)}
                  placeholder="e.g. When is the permission slip due? or What medication should I avoid?"
                  className="flex-1 px-4 py-2.5 text-sm rounded-xl border border-slate-200 focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                  disabled={isAsking}
                />
                <button
                  type="submit"
                  disabled={!questionInput.trim() || isAsking}
                  className="px-4 py-2.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-50 rounded-xl flex items-center gap-2 transition-colors cursor-pointer"
                >
                  {isAsking ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                  <span>Ask</span>
                </button>
              </form>

              {/* Sample suggestion prompts */}
              <div className="flex flex-wrap items-center gap-1.5 text-xs text-slate-500">
                <span className="text-[11px] font-medium text-slate-400">Quick questions:</span>
                {[
                  'What are the mandatory deadlines?',
                  'Are there any fees or penalties?',
                  'Who should I contact in an emergency?',
                ].map((sug, idx) => (
                  <button
                    key={idx}
                    onClick={() => setQuestionInput(sug)}
                    className="text-xs text-slate-600 hover:text-blue-600 bg-slate-100 hover:bg-blue-50 px-2 py-1 rounded-md transition-colors"
                  >
                    {sug}
                  </button>
                ))}
              </div>

              {/* QA History */}
              <div className="space-y-4 pt-4 border-t border-slate-100">
                {(!document.qaHistory || document.qaHistory.length === 0) ? (
                  <div className="py-8 text-center text-xs text-slate-400">
                    No questions asked yet. Ask anything about this document above!
                  </div>
                ) : (
                  document.qaHistory.map((item) => (
                    <div
                      key={item.id}
                      className="p-4 rounded-xl border border-slate-200/80 bg-slate-50/40 space-y-2"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-slate-900">
                          Q: {item.question}
                        </span>
                        <span className="text-[11px] text-slate-400 font-mono">
                          {new Date(item.timestamp).toLocaleTimeString()}
                        </span>
                      </div>

                      <p className="text-sm text-slate-800 leading-relaxed">
                        {item.answer}
                      </p>

                      {item.sourcePassage && (
                        <div className="p-2.5 rounded-lg bg-white border border-slate-200/60 text-xs text-slate-600">
                          <span className="font-semibold text-slate-500 text-[11px] block mb-0.5">
                            Cited Passage from Document:
                          </span>
                          <span className="italic">"{item.sourcePassage}"</span>
                        </div>
                      )}
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {/* TAB 7: Source Extracted Text */}
          {activeTab === 'original' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between gap-4">
                <p className="text-xs text-slate-500">
                  Exact raw text extracted via optical recognition / PDF parsing:
                </p>

                <div className="w-64">
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search inside text..."
                    className="w-full px-3 py-1.5 text-xs rounded-lg border border-slate-200 focus:border-blue-500"
                  />
                </div>
              </div>

              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs font-mono text-slate-800 whitespace-pre-wrap leading-relaxed max-h-[500px] overflow-y-auto select-text">
                {document.extractedText}
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
