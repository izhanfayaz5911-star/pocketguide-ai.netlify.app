import React, { useState, useEffect } from 'react';
import { 
  Camera, 
  Upload, 
  FileText, 
  Sparkles, 
  CheckSquare, 
  Clock, 
  ArrowRight, 
  ShieldCheck, 
  BookOpen, 
  Calendar,
  AlertCircle
} from 'lucide-react';
import { PocketDocument, ReadingLevel, UserPreferences } from './types/document';
import { getAllDocuments, saveDocument, deleteDocument, getUserPreferences, saveUserPreferences } from './lib/storage';
import { SAMPLE_DOCUMENTS } from './lib/sampleDocs';
import { Header } from './components/Header';
import { DocumentScanner } from './components/DocumentScanner';
import { DocumentWorkspace } from './components/DocumentWorkspace';
import { DocumentLibrary } from './components/DocumentLibrary';
import { PrivacyModal } from './components/PrivacyModal';
import { OnboardingModal } from './components/OnboardingModal';

export default function App() {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'scanner' | 'workspace' | 'library'>('dashboard');
  const [documents, setDocuments] = useState<PocketDocument[]>([]);
  const [activeDocument, setActiveDocument] = useState<PocketDocument | null>(null);
  const [hasGeminiKey, setHasGeminiKey] = useState<boolean>(false);
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [isLoadingDocs, setIsLoadingDocs] = useState<boolean>(true);

  // Modals
  const [isPrivacyOpen, setIsPrivacyOpen] = useState<boolean>(false);
  const [isOnboardingOpen, setIsOnboardingOpen] = useState<boolean>(false);
  const [preferences, setPreferences] = useState<UserPreferences>({
    defaultReadingLevel: 'standard',
    allowExternalAI: true,
    speechRate: 1.0,
    highContrast: false,
    hasSeenOnboarding: false,
  });

  // Initial load
  useEffect(() => {
    async function init() {
      // 1. Fetch server health and Gemini configuration status
      try {
        const res = await fetch('/api/health');
        if (res.ok) {
          const data = await res.json();
          setHasGeminiKey(!!data.hasGeminiKey);
        }
      } catch (e) {
        console.warn('API health check unreachable, operating in offline/client mode');
        setHasGeminiKey(false);
      }

      // 2. Load user preferences
      const prefs = await getUserPreferences();
      setPreferences(prefs);
      if (!prefs.hasSeenOnboarding) {
        setIsOnboardingOpen(true);
      }

      // 3. Load documents from IndexedDB
      const loadedDocs = await getAllDocuments();
      setDocuments(loadedDocs);
      if (loadedDocs.length > 0 && !activeDocument) {
        setActiveDocument(loadedDocs[0]);
      }
      setIsLoadingDocs(false);
    }

    init();
  }, []);

  const handleUpdatePreferences = async (newPrefs: UserPreferences) => {
    setPreferences(newPrefs);
    await saveUserPreferences(newPrefs);
  };

  const handleCloseOnboarding = async () => {
    setIsOnboardingOpen(false);
    const updated = { ...preferences, hasSeenOnboarding: true };
    await handleUpdatePreferences(updated);
  };

  // Perform Document Analysis
  const performAnalysis = async (doc: PocketDocument, readingLevel: ReadingLevel = preferences.defaultReadingLevel) => {
    setIsAnalyzing(true);
    try {
      // If external AI is disabled by user in privacy settings, use local analysis immediately
      if (!preferences.allowExternalAI) {
        const { analyzeDocumentLocally } = await import('../server/aiService');
        const localResult = analyzeDocumentLocally(doc.extractedText, readingLevel);
        const updated: PocketDocument = {
          ...doc,
          analysis: localResult,
          updatedAt: Date.now(),
        };
        await saveDocument(updated);
        setDocuments((prev) => [updated, ...prev.filter((d) => d.id !== updated.id)]);
        setActiveDocument(updated);
        return;
      }

      const res = await fetch('/api/ai/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: doc.extractedText,
          readingLevel,
        }),
      });

      if (!res.ok) {
        throw new Error(`Server returned ${res.status}`);
      }

      const analysis = await res.json();
      const updated: PocketDocument = {
        ...doc,
        analysis,
        updatedAt: Date.now(),
      };

      await saveDocument(updated);
      setDocuments((prev) => [updated, ...prev.filter((d) => d.id !== updated.id)]);
      setActiveDocument(updated);
    } catch (err) {
      console.error('Analysis error; falling back to local processing:', err);
      // Fallback to local rule-based analysis
      const { analyzeDocumentLocally } = await import('../server/aiService');
      const localResult = analyzeDocumentLocally(doc.extractedText, readingLevel);
      const updated: PocketDocument = {
        ...doc,
        analysis: localResult,
        updatedAt: Date.now(),
      };
      await saveDocument(updated);
      setDocuments((prev) => [updated, ...prev.filter((d) => d.id !== updated.id)]);
      setActiveDocument(updated);
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Create new document from scanner
  const handleDocumentCreated = async (newDoc: PocketDocument) => {
    await saveDocument(newDoc);
    setDocuments((prev) => [newDoc, ...prev]);
    setActiveDocument(newDoc);
    setActiveTab('workspace');
    await performAnalysis(newDoc, preferences.defaultReadingLevel);
  };

  // Select document to view
  const handleSelectDocument = (doc: PocketDocument) => {
    setActiveDocument(doc);
    setActiveTab('workspace');
  };

  // Delete document
  const handleDeleteDocument = async (id: string) => {
    await deleteDocument(id);
    const remaining = documents.filter((d) => d.id !== id);
    setDocuments(remaining);
    if (activeDocument?.id === id) {
      setActiveDocument(remaining[0] || null);
      if (remaining.length === 0) {
        setActiveTab('dashboard');
      }
    }
  };

  // Rename document
  const handleRenameDocument = async (id: string, newTitle: string) => {
    const doc = documents.find((d) => d.id === id);
    if (!doc) return;
    const updated = { ...doc, title: newTitle, updatedAt: Date.now() };
    await saveDocument(updated);
    setDocuments((prev) => prev.map((d) => (d.id === id ? updated : d)));
    if (activeDocument?.id === id) {
      setActiveDocument(updated);
    }
  };

  // Update document (e.g. checklist or qa update)
  const handleUpdateDocument = async (updatedDoc: PocketDocument) => {
    await saveDocument(updatedDoc);
    setDocuments((prev) => prev.map((d) => (d.id === updatedDoc.id ? updatedDoc : d)));
    setActiveDocument(updatedDoc);
  };

  // Re-analyze document with new reading level
  const handleReanalyze = async (doc: PocketDocument, readingLevel: ReadingLevel) => {
    await performAnalysis(doc, readingLevel);
  };

  // 1-Click Load Sample Document
  const handleLoadSample = async (sampleId: string) => {
    const sample = SAMPLE_DOCUMENTS.find((s) => s.id === sampleId) || SAMPLE_DOCUMENTS[0];
    const newDoc: PocketDocument = {
      id: `doc-${Date.now()}`,
      title: sample.title,
      category: sample.category,
      extractedText: sample.extractedText,
      originalFileName: sample.fileName,
      fileType: 'sample',
      qaHistory: [],
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };

    await saveDocument(newDoc);
    setDocuments((prev) => [newDoc, ...prev.filter((d) => d.id !== newDoc.id)]);
    setActiveDocument(newDoc);
    setActiveTab('workspace');
    await performAnalysis(newDoc, preferences.defaultReadingLevel);
  };

  // Calculate global task stats
  const totalTasks = documents.reduce((acc, d) => acc + (d.analysis?.actions.length || 0), 0);
  const completedTasks = documents.reduce(
    (acc, d) => acc + (d.analysis?.actions.filter((a) => a.completed).length || 0),
    0
  );
  const pendingTasks = totalTasks - completedTasks;

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 font-sans">
      {/* Top Bar Navigation */}
      <Header
        activeTab={activeTab === 'workspace' ? 'library' : activeTab}
        setActiveTab={(tab) => {
          setActiveTab(tab);
        }}
        onOpenPrivacy={() => setIsPrivacyOpen(true)}
        onNewScan={() => setActiveTab('scanner')}
        hasGeminiKey={hasGeminiKey}
      />

      {/* Main Content Viewport */}
      <main className="flex-1">
        {/* VIEW 1: Dashboard */}
        {activeTab === 'dashboard' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
            
            {/* Hero Welcome & Quick Stats */}
            <div className="bg-white rounded-3xl border border-slate-200/80 p-8 shadow-xs relative overflow-hidden">
              <div className="max-w-2xl space-y-3 relative z-10">
                <div className="flex items-center gap-2 text-xs font-medium text-slate-500">
                  <span>Welcome to PocketGuide AI</span>
                  <span aria-hidden="true">·</span>
                  <span className="text-emerald-700 font-semibold flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    Local-First Storage Active
                  </span>
                </div>

                <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-slate-900 leading-tight">
                  Understand complicated paperwork in seconds.
                </h1>

                <p className="text-sm text-slate-600 leading-relaxed">
                  Upload or photograph school notices, medical care plans, government letters, utility bills, or appliance manuals. We translate dense bureaucratic fine print into plain language and actionable checklists.
                </p>

                {/* Primary CTA buttons */}
                <div className="flex flex-wrap items-center gap-3 pt-2">
                  <button
                    onClick={() => setActiveTab('scanner')}
                    className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-semibold text-sm shadow-xs transition-colors cursor-pointer"
                  >
                    <Camera className="w-4 h-4" />
                    <span>Scan or Upload Document</span>
                  </button>

                  <button
                    onClick={() => handleLoadSample(SAMPLE_DOCUMENTS[0].id)}
                    className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-sm transition-colors cursor-pointer"
                  >
                    <BookOpen className="w-4 h-4" />
                    <span>Try Sample School Notice</span>
                  </button>
                </div>
              </div>

              {/* Decorative Subtle Background Graphics */}
              <div className="hidden lg:block absolute right-8 top-1/2 -translate-y-1/2 w-64 h-64 opacity-5 pointer-events-none">
                <svg viewBox="0 0 200 200" fill="currentColor" className="w-full h-full text-blue-900">
                  <circle cx="100" cy="100" r="80" />
                </svg>
              </div>
            </div>

            {/* Quick Metrics Strip */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-xs space-y-1">
                <span className="text-xs text-slate-500 font-medium">Saved Documents</span>
                <p className="text-2xl font-bold font-mono tabular-nums text-slate-900">
                  {documents.length}
                </p>
                <p className="text-[11px] text-slate-400">Stored locally in IndexedDB</p>
              </div>

              <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-xs space-y-1">
                <span className="text-xs text-slate-500 font-medium">Action Items Pending</span>
                <p className="text-2xl font-bold font-mono tabular-nums text-blue-600">
                  {pendingTasks}
                </p>
                <p className="text-[11px] text-slate-400">
                  {completedTasks} completed across documents
                </p>
              </div>

              <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-xs space-y-1">
                <span className="text-xs text-slate-500 font-medium">Processing Engine</span>
                <p className="text-sm font-bold text-slate-900 pt-1">
                  {hasGeminiKey ? 'Gemini 3.8 Flash' : 'Deterministic Local Fallback'}
                </p>
                <p className="text-[11px] text-slate-400">
                  {hasGeminiKey ? 'Active via server environment' : '100% on-device & private'}
                </p>
              </div>
            </div>

            {/* Recent Documents & Quick Inspection */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-lg font-bold text-slate-900">Recent Documents</h2>
                  <p className="text-xs text-slate-500">Pick up where you left off</p>
                </div>

                <button
                  onClick={() => setActiveTab('library')}
                  className="text-xs font-semibold text-blue-600 hover:text-blue-800 flex items-center gap-1"
                >
                  <span>View All ({documents.length})</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>

              {documents.length === 0 ? (
                <div className="py-12 text-center bg-white rounded-2xl border border-dashed border-slate-200 p-8">
                  <FileText className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                  <p className="text-sm font-semibold text-slate-700">No documents yet</p>
                  <p className="text-xs text-slate-500 mt-1">Scan or upload your first document to see it here.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {documents.slice(0, 6).map((doc) => {
                    const doneCount = doc.analysis?.actions.filter((a) => a.completed).length || 0;
                    const actCount = doc.analysis?.actions.length || 0;

                    return (
                      <div
                        key={doc.id}
                        onClick={() => handleSelectDocument(doc)}
                        className="group bg-white rounded-2xl border border-slate-200/80 hover:border-blue-400 p-5 shadow-xs hover:shadow-sm transition-all cursor-pointer flex flex-col justify-between"
                      >
                        <div className="space-y-2.5">
                          <div className="flex items-center justify-between text-[11px] text-slate-400 font-medium">
                            <span>{doc.category}</span>
                            <span className="font-mono tabular-nums">
                              {new Date(doc.updatedAt).toLocaleDateString()}
                            </span>
                          </div>

                          <h3 className="text-base font-bold text-slate-900 group-hover:text-blue-600 transition-colors line-clamp-1">
                            {doc.title}
                          </h3>

                          <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                            {doc.analysis?.summary || doc.extractedText.slice(0, 120)}
                          </p>
                        </div>

                        <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between text-xs">
                          <span className="text-[11px] text-slate-500 font-mono">
                            {actCount > 0 ? `${doneCount}/${actCount} tasks complete` : 'No tasks'}
                          </span>
                          <span className="font-semibold text-blue-600 group-hover:underline flex items-center gap-1">
                            Open <ArrowRight className="w-3 h-3" />
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Fictional Sample Documents Showcase */}
            <div className="bg-slate-100/60 rounded-3xl p-6 border border-slate-200/60 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-slate-900">
                    Test Scenarios (Immediate 1-Click Verification)
                  </h3>
                  <p className="text-xs text-slate-500">
                    Pre-packaged realistic use cases with dates, compliance warnings, and checklists.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                {SAMPLE_DOCUMENTS.map((s) => (
                  <button
                    key={s.id}
                    onClick={() => handleLoadSample(s.id)}
                    className="p-4 rounded-xl bg-white border border-slate-200/80 hover:border-blue-400 text-left transition-all group shadow-2xs cursor-pointer flex flex-col justify-between"
                  >
                    <div className="space-y-1">
                      <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
                        {s.category}
                      </span>
                      <h4 className="text-xs font-bold text-slate-900 group-hover:text-blue-600 line-clamp-2">
                        {s.title}
                      </h4>
                    </div>

                    <span className="mt-3 text-[11px] font-semibold text-blue-600 flex items-center gap-1">
                      Inspect & Explain <ArrowRight className="w-3 h-3" />
                    </span>
                  </button>
                ))}
              </div>
            </div>

          </div>
        )}

        {/* VIEW 2: Document Scanner */}
        {activeTab === 'scanner' && (
          <DocumentScanner
            onDocumentCreated={handleDocumentCreated}
            onCancel={() => setActiveTab('dashboard')}
          />
        )}

        {/* VIEW 3: Document Workspace */}
        {activeTab === 'workspace' && activeDocument && (
          <DocumentWorkspace
            document={activeDocument}
            onUpdateDocument={handleUpdateDocument}
            onReanalyze={handleReanalyze}
            isAnalyzing={isAnalyzing}
          />
        )}

        {/* VIEW 4: Document Library */}
        {activeTab === 'library' && (
          <DocumentLibrary
            documents={documents}
            onSelectDocument={handleSelectDocument}
            onDeleteDocument={handleDeleteDocument}
            onRenameDocument={handleRenameDocument}
            onNewScan={() => setActiveTab('scanner')}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="mt-auto border-t border-slate-200/80 bg-white py-6 px-4 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-800">PocketGuide AI</span>
            <span aria-hidden="true">·</span>
            <span>Document Understanding Assistant</span>
            <span aria-hidden="true">·</span>
            <span className="text-slate-400">Budget ₹0</span>
          </div>

          <div className="flex items-center gap-4 text-slate-500">
            <button
              onClick={() => setIsPrivacyOpen(true)}
              className="hover:text-slate-900 transition-colors"
            >
              Privacy & Security
            </button>
            <button
              onClick={() => setIsOnboardingOpen(true)}
              className="hover:text-slate-900 transition-colors"
            >
              How It Works
            </button>
          </div>
        </div>
      </footer>

      {/* Privacy & Settings Modal */}
      <PrivacyModal
        isOpen={isPrivacyOpen}
        onClose={() => setIsPrivacyOpen(false)}
        preferences={preferences}
        onUpdatePreferences={handleUpdatePreferences}
        onDataReset={() => {
          setDocuments([]);
          setActiveDocument(null);
          setActiveTab('dashboard');
        }}
      />

      {/* Onboarding Walkthrough Modal */}
      <OnboardingModal
        isOpen={isOnboardingOpen}
        onClose={handleCloseOnboarding}
        onStartScan={() => {
          handleCloseOnboarding();
          setActiveTab('scanner');
        }}
        onTrySample={() => {
          handleCloseOnboarding();
          handleLoadSample(SAMPLE_DOCUMENTS[0].id);
        }}
      />
    </div>
  );
}
