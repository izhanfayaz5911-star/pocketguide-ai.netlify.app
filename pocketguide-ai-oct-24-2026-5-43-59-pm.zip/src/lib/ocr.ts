import { createWorker } from 'tesseract.js';
import * as pdfjsLib from 'pdfjs-dist';

// Configure pdfjs worker
// Use unpkg or cdnjs worker if available, or fallback gracefully
if (typeof window !== 'undefined' && pdfjsLib.GlobalWorkerOptions) {
  pdfjsLib.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version || '4.10.38'}/pdf.worker.min.mjs`;
}

export interface OCRProgress {
  status: string;
  progress: number; // 0 to 1
  page?: number;
  totalPages?: number;
}

/**
 * Perform real OCR on an image file, Blob, or base64 data URL using Tesseract.js
 */
export async function performImageOCR(
  imageSource: string | File | Blob,
  onProgress?: (progress: OCRProgress) => void
): Promise<{ text: string; confidence: number }> {
  try {
    if (onProgress) {
      onProgress({ status: 'Initializing OCR engine...', progress: 0.1 });
    }

    const worker = await createWorker('eng', 1, {
      logger: (m) => {
        if (onProgress && m.status) {
          const p = m.progress !== undefined ? Math.min(0.95, 0.15 + m.progress * 0.8) : 0.5;
          const statusText = m.status === 'recognizing text' 
            ? `Reading text (${Math.round((m.progress || 0) * 100)}%)...` 
            : `Preparing engine: ${m.status}...`;
          onProgress({
            status: statusText,
            progress: p,
          });
        }
      },
    });

    if (onProgress) {
      onProgress({ status: 'Analyzing document structure...', progress: 0.85 });
    }

    const ret = await worker.recognize(imageSource);
    await worker.terminate();

    if (onProgress) {
      onProgress({ status: 'Processing complete', progress: 1.0 });
    }

    const cleanText = ret.data.text.trim();
    return {
      text: cleanText || '(No readable text could be recognized. Please check lighting or crop closer.)',
      confidence: Math.round(ret.data.confidence),
    };
  } catch (error: any) {
    console.error('OCR Error:', error);
    throw new Error(`Text recognition failed: ${error.message || 'Unknown OCR error'}`);
  }
}

/**
 * Extract text from a PDF file using pdfjs-dist.
 * If text content is sparse (e.g. scanned image PDF), renders page to canvas and runs Tesseract OCR.
 */
export async function extractPDFText(
  file: File | ArrayBuffer,
  onProgress?: (progress: OCRProgress) => void
): Promise<{ text: string; pageCount: number; confidence: number }> {
  try {
    const arrayBuffer = file instanceof File ? await file.arrayBuffer() : file;
    const loadingTask = pdfjsLib.getDocument({ data: arrayBuffer });
    const pdf = await loadingTask.promise;
    const pageCount = pdf.numPages;

    let fullText = '';
    let hasDigitalText = false;

    for (let pageNum = 1; pageNum <= pageCount; pageNum++) {
      if (onProgress) {
        onProgress({
          status: `Extracting page ${pageNum} of ${pageCount}...`,
          progress: pageNum / (pageCount + 1),
          page: pageNum,
          totalPages: pageCount,
        });
      }

      const page = await pdf.getPage(pageNum);
      const textContent = await page.getTextContent();
      const pageStrings = textContent.items
        .map((item: any) => ('str' in item ? item.str : ''))
        .filter((s: string) => s.trim().length > 0);

      const pageText = pageStrings.join(' ');
      if (pageText.trim().length > 30) {
        hasDigitalText = true;
        fullText += `--- Page ${pageNum} ---\n` + pageText + '\n\n';
      }
    }

    // If PDF has digital text, return it immediately with high confidence
    if (hasDigitalText && fullText.trim().length > 50) {
      if (onProgress) {
        onProgress({ status: 'Extraction complete', progress: 1.0 });
      }
      return {
        text: fullText.trim(),
        pageCount,
        confidence: 99,
      };
    }

    // Otherwise, this is a scanned PDF (image only)
    // Render the first page to canvas and perform OCR
    if (onProgress) {
      onProgress({ status: 'Scanned PDF detected. Rendering page for visual OCR...', progress: 0.6 });
    }

    const firstPage = await pdf.getPage(1);
    const viewport = firstPage.getViewport({ scale: 2.0 });
    const canvas = document.createElement('canvas');
    canvas.width = viewport.width;
    canvas.height = viewport.height;
    const ctx = canvas.getContext('2d');

    if (!ctx) {
      throw new Error('Canvas 2D context not available');
    }

    await firstPage.render({ canvasContext: ctx, viewport, canvas } as any).promise;
    const imageDataUrl = canvas.toDataURL('image/png');

    const ocrResult = await performImageOCR(imageDataUrl, onProgress);
    return {
      text: `--- Page 1 (Scanned) ---\n` + ocrResult.text,
      pageCount,
      confidence: ocrResult.confidence,
    };
  } catch (error: any) {
    console.error('PDF extraction failed:', error);
    throw new Error(`Could not extract PDF text: ${error.message || 'Corrupted or encrypted PDF'}`);
  }
}

/**
 * Rotate an image by specified degrees (90, 180, 270)
 */
export async function rotateImageDataUrl(dataUrl: string, degrees: number): Promise<string> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        resolve(dataUrl);
        return;
      }

      const rad = (degrees * Math.PI) / 180;
      const is90or270 = degrees % 180 !== 0;

      canvas.width = is90or270 ? img.height : img.width;
      canvas.height = is90or270 ? img.width : img.height;

      ctx.translate(canvas.width / 2, canvas.height / 2);
      ctx.rotate(rad);
      ctx.drawImage(img, -img.width / 2, -img.height / 2);

      resolve(canvas.toDataURL('image/jpeg', 0.92));
    };
    img.onerror = reject;
    img.src = dataUrl;
  });
}
