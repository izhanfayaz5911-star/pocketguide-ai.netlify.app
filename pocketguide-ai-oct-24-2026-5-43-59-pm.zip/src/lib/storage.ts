import { PocketDocument, UserPreferences } from '../types/document';
import { SAMPLE_DOCUMENTS } from './sampleDocs';

const DB_NAME = 'PocketGuideAI_DB';
const DB_VERSION = 1;
const STORE_DOCS = 'documents';
const STORE_PREFS = 'preferences';

const DEFAULT_PREFERENCES: UserPreferences = {
  defaultReadingLevel: 'standard',
  allowExternalAI: true,
  speechRate: 1.0,
  highContrast: false,
  hasSeenOnboarding: false,
};

let dbPromise: Promise<IDBDatabase> | null = null;

function getDB(): Promise<IDBDatabase> {
  if (dbPromise) return dbPromise;

  dbPromise = new Promise((resolve, reject) => {
    if (typeof window === 'undefined' || !window.indexedDB) {
      reject(new Error('IndexedDB not supported'));
      return;
    }

    const request = window.indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(STORE_DOCS)) {
        const docStore = db.createObjectStore(STORE_DOCS, { keyPath: 'id' });
        docStore.createIndex('updatedAt', 'updatedAt', { unique: false });
        docStore.createIndex('category', 'category', { unique: false });
      }
      if (!db.objectStoreNames.contains(STORE_PREFS)) {
        db.createObjectStore(STORE_PREFS, { keyPath: 'key' });
      }
    };

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });

  return dbPromise;
}

// Fallback to localStorage if IndexedDB is blocked
const LOCAL_STORAGE_DOCS_KEY = 'pocketguide_documents';
const LOCAL_STORAGE_PREFS_KEY = 'pocketguide_preferences';

function getLocalStorageDocs(): PocketDocument[] {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_DOCS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function saveLocalStorageDocs(docs: PocketDocument[]) {
  try {
    localStorage.setItem(LOCAL_STORAGE_DOCS_KEY, JSON.stringify(docs));
  } catch (e) {
    console.error('LocalStorage write failed:', e);
  }
}

export async function getAllDocuments(): Promise<PocketDocument[]> {
  try {
    const db = await getDB();
    return new Promise((resolve) => {
      const tx = db.transaction(STORE_DOCS, 'readonly');
      const store = tx.objectStore(STORE_DOCS);
      const req = store.getAll();
      req.onsuccess = () => {
        let docs: PocketDocument[] = req.result || [];
        // If empty, initialize with the first sample document so the user can immediately experience the app
        if (docs.length === 0) {
          const sample = SAMPLE_DOCUMENTS[0];
          const initialDoc: PocketDocument = {
            id: sample.id,
            title: sample.title,
            category: sample.category,
            extractedText: sample.extractedText,
            originalFileName: sample.fileName,
            fileType: 'sample',
            qaHistory: [],
            createdAt: Date.now() - 3600000,
            updatedAt: Date.now() - 3600000,
          };
          saveDocument(initialDoc).catch(() => {});
          docs = [initialDoc];
        }
        docs.sort((a, b) => b.updatedAt - a.updatedAt);
        resolve(docs);
      };
      req.onerror = () => {
        resolve(getLocalStorageDocs());
      };
    });
  } catch {
    return getLocalStorageDocs();
  }
}

export async function getDocument(id: string): Promise<PocketDocument | null> {
  try {
    const db = await getDB();
    return new Promise((resolve) => {
      const tx = db.transaction(STORE_DOCS, 'readonly');
      const store = tx.objectStore(STORE_DOCS);
      const req = store.get(id);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => {
        const found = getLocalStorageDocs().find(d => d.id === id);
        resolve(found || null);
      };
    });
  } catch {
    const found = getLocalStorageDocs().find(d => d.id === id);
    return found || null;
  }
}

export async function saveDocument(doc: PocketDocument): Promise<void> {
  doc.updatedAt = Date.now();
  try {
    const db = await getDB();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_DOCS, 'readwrite');
      const store = tx.objectStore(STORE_DOCS);
      const req = store.put(doc);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  } catch {
    const docs = getLocalStorageDocs();
    const index = docs.findIndex(d => d.id === doc.id);
    if (index >= 0) {
      docs[index] = doc;
    } else {
      docs.push(doc);
    }
    saveLocalStorageDocs(docs);
  }
}

export async function deleteDocument(id: string): Promise<void> {
  try {
    const db = await getDB();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_DOCS, 'readwrite');
      const store = tx.objectStore(STORE_DOCS);
      const req = store.delete(id);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  } catch {
    const docs = getLocalStorageDocs().filter(d => d.id !== id);
    saveLocalStorageDocs(docs);
  }
}

export async function getUserPreferences(): Promise<UserPreferences> {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_PREFS_KEY);
    if (raw) {
      return { ...DEFAULT_PREFERENCES, ...JSON.parse(raw) };
    }
  } catch {
    // fallback
  }
  return DEFAULT_PREFERENCES;
}

export async function saveUserPreferences(prefs: UserPreferences): Promise<void> {
  try {
    localStorage.setItem(LOCAL_STORAGE_PREFS_KEY, JSON.stringify(prefs));
  } catch (e) {
    console.error('Failed to save preferences:', e);
  }
}

export async function clearAllData(): Promise<void> {
  try {
    const db = await getDB();
    const tx = db.transaction(STORE_DOCS, 'readwrite');
    tx.objectStore(STORE_DOCS).clear();
  } catch {
    // ignore
  }
  localStorage.removeItem(LOCAL_STORAGE_DOCS_KEY);
  localStorage.removeItem(LOCAL_STORAGE_PREFS_KEY);
}

export async function exportAllDataAsJSON(): Promise<string> {
  const docs = await getAllDocuments();
  const prefs = await getUserPreferences();
  return JSON.stringify({
    appName: 'PocketGuide AI',
    exportedAt: new Date().toISOString(),
    version: '1.0.0',
    preferences: prefs,
    documents: docs,
  }, null, 2);
}
