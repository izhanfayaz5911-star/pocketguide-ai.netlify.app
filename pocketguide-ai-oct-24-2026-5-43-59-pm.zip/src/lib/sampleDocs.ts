import { DocumentCategory } from '../types/document';

export interface SampleDoc {
  id: string;
  title: string;
  category: DocumentCategory;
  fileName: string;
  summaryPreview: string;
  extractedText: string;
}

export const SAMPLE_DOCUMENTS: SampleDoc[] = [
  {
    id: 'sample-school-trip',
    title: 'Oakridge Middle School - 8th Grade Science Excursion Notice',
    category: 'School & Education',
    fileName: 'Oakridge_Science_Trip_Notice.pdf',
    summaryPreview: 'Notice and permission slip for the 8th grade science expedition to the Pacific Marine Sanctuary on Nov 14, 2026.',
    extractedText: `OAKRIDGE MIDDLE SCHOOL
DEPARTMENT OF NATURAL SCIENCES
1042 Academic Parkway, Seattle, WA 98105
Phone: (206) 555-0192 | Email: science-dept@oakridgek12.org

October 18, 2026

Dear Parent or Legal Guardian,

Re: Mandatory Permission Slip and Health Form for Annual Marine Biology Field Study

We are pleased to announce the 8th Grade Field Expedition to the Pacific Marine Sanctuary in Anacortes, WA, scheduled for Friday, November 14, 2026. This trip fulfills the Washington State oceanographic ecology curriculum requirements.

KEY LOGISTICAL DETAILS:
- Departure: Friday, November 14, 2026 at 06:45 AM sharp from the North Bus Loop. Buses depart promptly at 07:00 AM.
- Return: Same day at approximately 05:30 PM. Parents must arrange prompt pickup by 05:45 PM.
- Trip Fee: $42.00 per student (covers round-trip chartered transit and lab admission). Subsidized fee waivers are available upon confidential request to Counselor Rivera before November 1, 2026.
- Payment Methods: Online via the Parent Portal (Transaction code: OMS-BIO-2026) or cash/check payable to "Oakridge Middle School".

MANDATORY ACTION ITEMS FOR PARENTS & GUARDIANS:
1. Complete and sign the attached Section B (Liability Release & Swimming Waiver).
2. Return signed permission slip and emergency contact form no later than Friday, November 7, 2026 at 03:00 PM to Room 214 (Mr. Henderson). Late submissions cannot be accommodated due to charter bus manifest regulations.
3. If your child requires prescription medication (such as asthma inhalers or EpiPens), submit Nurse Authorization Form 4-B with the school health office by Wednesday, November 5, 2026.
4. Provide a sack lunch in a disposable brown bag (no glass containers or refrigeration available).

WHAT STUDENTS MUST BRING:
- Weatherproof jacket with hood (ocean temperatures are cold and windy).
- Waterproof hiking boots or sturdy closed-toe sneakers. No sandals or open-toed footwear permitted.
- Spiral notebook, two pencils, and student ID card.

EMERGENCY CONTACTS ON TRIP DAY:
Lead Faculty Chaperone: Dr. Aris Thorne (Cell: 206-555-8831)
Sanctuary Field Office: (360) 555-2204
Reference Case ID: OMS-EXP-9402

Please note: All school conduct guidelines remain strictly in force throughout off-campus transport and sanctuary facilities.`
  },
  {
    id: 'sample-medical-discharge',
    title: 'St. Jude Community Health - Post-Procedure Discharge Instructions',
    category: 'Medical & Health',
    fileName: 'Discharge_Instructions_Care_Plan.pdf',
    summaryPreview: 'Post-operative recovery plan, wound dressing care, medication timing, and urgent warning signs following arthroscopic procedure.',
    extractedText: `ST. JUDE REGIONAL SURGICAL CENTER
POST-PROCEDURE CARE PLAN & DISCHARGE SUMMARY
Patient MRN: #892-0419-X | Date of Procedure: October 22, 2026
Attending Surgeon: Dr. Elena Vance, MD | Care Coordinator: Marcus Brody, RN

PATIENT DISCHARGE DIAGNOSIS:
Right Knee Diagnostic Arthroscopy with Partial Meniscal Debridement.
Status: Stable. Cleared for home convalescence under 24-hour adult supervision.

MEDICATION SCHEDULE & PAIN MANAGEMENT:
1. Acetaminophen (Tylenol) 500mg: Take 2 tablets every 6 hours as needed for mild-to-moderate discomfort. Do NOT exceed 3,000mg in any 24-hour cycle.
2. Ibuprofen (Advil/Motrin) 600mg: Take 1 tablet with food every 8 hours for inflammation.
3. Oxycodone 5mg: Take 1 tablet every 4 to 6 hours ONLY for severe breakthrough pain. Caution: Causes drowsiness; do not drive, operate machinery, or consume alcohol while taking.
4. Aspirin 81mg (Low-Dose): Take 1 tablet once daily with breakfast for 14 days to prevent venous blood clots.

WOUND CARE & HYGIENE:
- Keep original dressing clean and dry for the first 48 hours (until Saturday, October 24 at 10:00 AM).
- After 48 hours, you may gently remove the outer Ace bandage and gauze. Do NOT remove the sterile adhesive strips (Steri-Strips) across the puncture portals.
- You may shower after 48 hours; do not submerge leg in bathtub, pool, or hot tub for at least 14 days. Pat dry gently.
- Ice therapy: Apply cold ice pack wrapped in a dry towel for 20 minutes every 2 hours while awake for the first 4 days.

ACTIVITY RESTRICTIONS:
- Weight-bearing as tolerated using bilateral crutches for the first 72 hours.
- Elevate right leg above heart level when resting on couch or bed.
- Refrain from vigorous exercise, running, deep squats, or heavy lifting (>10 lbs) until cleared.

FOLLOW-UP APPOINTMENT:
Your post-operative follow-up is scheduled for Tuesday, November 3, 2026 at 09:15 AM at Clinic Suite 400 with Physician Assistant Sarah Lin. Call (503) 555-0144 if you need to reschedule.

WHEN TO SEEK IMMEDIATE MEDICAL ATTENTION (CALL 911 OR VISIT EMERGENCY ROOM):
- Persistent calf pain, significant swelling, or warmth in the lower leg (potential blood clot).
- Fever exceeding 101.4°F (38.5°C) or chills.
- Copious bright red drainage or foul-smelling discharge soaking through bandages.
- Sudden shortness of breath or sharp chest discomfort.`
  },
  {
    id: 'sample-utility-notice',
    title: 'Metro Water Authority - Mandatory Backflow Inspection Notice',
    category: 'Financial & Bills',
    fileName: 'Water_Authority_Compliance_Notice.pdf',
    summaryPreview: 'Annual mandatory cross-connection backflow prevention testing compliance order and certified tester submission guidelines.',
    extractedText: `METROPOLITAN WATER & UTILITY COMMISSION
CROSS-CONNECTION CONTROL DIVISION
800 Waterway Plaza, Austin, TX 78701
Official Notice Reference: CC-2026-88192-TX
Account Number: #9314-5502-01 | Service Address: 1420 Crestview Terrace

Date of Issuance: October 15, 2026
FINAL NOTICE BEFORE COMPLIANCE ACTION

Dear Property Owner or Designated Agent:

Under City Municipal Code Section 15-29 and Texas Administrative Code 30 TAC §290.47, all commercial, mixed-use, and dedicated irrigation water service connections are required to undergo an annual inspection of their backflow prevention assemblies to protect the potable public water supply.

CURRENT RECORD STATUS:
Assembly Location: Irrigation Meter Pit #1 (East Boundary)
Serial Number: Febco 825Y-09824
Status: PAST DUE (Previous test expired September 30, 2026).

MANDATORY REQUIREMENTS:
1. Certified Inspection: You must engage a state-licensed Backflow Prevention Assembly Tester (BPAT). A searchable directory of registered independent contractors is available at www.metrowater.gov/testers.
2. Compliance Deadline: The certified Test and Maintenance Report must be submitted to the Commission by Friday, November 20, 2026, at 05:00 PM CST.
3. Submission Portal: Certified testers must file the form digitally through the WaterComply Online Portal. Ensure the tester includes your Account Number (#9314-5502-01) and Serial Number.
4. Administrative Filing Fee: A $25.00 compliance processing fee will be billed directly to your December utility statement upon verification.

PENALTIES FOR NON-COMPLIANCE:
If a verified passing test report is not submitted on or before November 20, 2026:
- A non-refundable Administrative Non-Compliance Penalty of $150.00 will be assessed against Account #9314-5502-01 on November 21, 2026.
- A 72-hour Disconnection Warning will be posted on the property.
- Continued failure to comply may result in physical termination of water service to prevent potential contamination of the municipal water grid. Service restoration requires payment of all past fees plus a $180.00 reconnection charge.

CONTACT AND INQUIRIES:
Office Hours: Monday through Friday, 8:00 AM - 4:30 PM CST
Telephone: (512) 555-0377
Email: backflow@metrowater.gov`
  },
  {
    id: 'sample-appliance-manual',
    title: 'AeroChef MasterPro Induction Cooktop - Safety & Error Troubleshooting',
    category: 'Manuals & Tech',
    fileName: 'AeroChef_Pro_User_Guide_Excerpt.pdf',
    summaryPreview: 'Quick reference guide for error codes E02, E05, E08, cookware compatibility guidelines, and electrical installation safety.',
    extractedText: `AEROCHEF MASTERPRO 30" BUILT-IN INDUCTION COOKTOP
QUICK SETUP & SAFETY TROUBLESHOOTING GUIDE (MODEL: AC-IND-3000)

ELECTRICAL SPECIFICATIONS:
- Voltage: 240V AC, 60Hz, dedicated 40-Amp circuit breaker required.
- Do NOT use an extension cord or multi-outlet adapter. Installation must be performed by a licensed electrician in accordance with NEC NFPA 70.

SUITABLE COOKWARE REQUIREMENTS:
Induction heating relies on electromagnetic coils. Cookware must have a flat ferromagnetic base (cast iron, enameled steel, or magnetic stainless steel).
- Magnet Test: If a magnet sticks firmly to the underside of the pan, it is compatible.
- Minimum pan base diameter is 4.75 inches (12 cm). Pans smaller than this threshold will trigger the "Pan Detection" icon.

CRITICAL ERROR CODES AND ACTIONS:
1. Error Code E02 (Overheating Protection Triggered):
   - Meaning: The internal sensor has detected excessive glass surface temperature (>450°F) or the cooling fan is obstructed.
   - Action Required: Turn off the unit immediately. Allow to cool for 20 minutes. Inspect under-counter intake vents for dust or paper blockages. If error persists after cooling, disconnect power at main breaker.

2. Error Code E05 (Incompatible Pan / Empty Pan Alert):
   - Meaning: Cookware material is non-magnetic (aluminum, copper, glass) or pan has boiled dry.
   - Action Required: Switch to magnetic induction-ready cookware. Never heat empty cookware at Power Boost level (Level 9).

3. Error Code E08 (Voltage Instability):
   - Meaning: Line voltage has dropped below 190V or surged above 265V.
   - Action Required: Power down unit. Contact a qualified electrical contractor to inspect your home electrical panel.

CLEANING AND MAINTENANCE:
- Clean ceramic glass surface only after the "H" (Hot Surface) warning indicator turns off.
- Use a dedicated ceramic glass cooktop scraper held at a 45-degree angle for burnt-on sugar or starch deposits.
- Never use abrasive scouring pads, bleach, or ammonia spray.

WARRANTY CLAIM SUPPORT:
AeroChef North America Customer Care: 1-800-555-0188 (Mon-Sat 7am-7pm EST)
Serial Number Label Location: Underside metal housing near power junction box.
Keep original purchase receipt to validate 2-Year Limited Manufacturer Warranty.`
  }
];
