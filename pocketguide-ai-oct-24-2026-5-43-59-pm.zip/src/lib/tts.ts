export interface TTSState {
  isPlaying: boolean;
  isPaused: boolean;
  currentText: string;
  rate: number;
}

export type TTSCallback = (state: TTSState) => void;

class TTSService {
  private synth: SpeechSynthesis | null = null;
  private currentUtterance: SpeechSynthesisUtterance | null = null;
  private chunks: string[] = [];
  private currentChunkIndex: number = 0;
  private state: TTSState = {
    isPlaying: false,
    isPaused: false,
    currentText: '',
    rate: 1.0,
  };
  private listeners: Set<TTSCallback> = new Set();
  private voices: SpeechSynthesisVoice[] = [];

  constructor() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      this.synth = window.speechSynthesis;
      this.loadVoices();
      if (this.synth.onvoiceschanged !== undefined) {
        this.synth.onvoiceschanged = () => this.loadVoices();
      }
    }
  }

  private loadVoices() {
    if (!this.synth) return;
    this.voices = this.synth.getVoices();
  }

  public isAvailable(): boolean {
    return !!this.synth;
  }

  public getVoices(): SpeechSynthesisVoice[] {
    if (this.voices.length === 0 && this.synth) {
      this.voices = this.synth.getVoices();
    }
    return this.voices;
  }

  public subscribe(cb: TTSCallback): () => void {
    this.listeners.add(cb);
    cb(this.state);
    return () => this.listeners.delete(cb);
  }

  private notify() {
    this.listeners.forEach((cb) => cb({ ...this.state }));
  }

  public speak(text: string, rate = 1.0, voiceName?: string) {
    if (!this.synth) return;

    this.stop();

    if (!text || text.trim().length === 0) return;

    this.state.currentText = text;
    this.state.rate = rate;
    this.state.isPlaying = true;
    this.state.isPaused = false;
    this.notify();

    // Chunk text into sentence segments to prevent browser speech synthesis timeouts
    const sentences = text
      .replace(/([.?!])\s+/g, '$1|')
      .split('|')
      .filter((s) => s.trim().length > 0);

    this.chunks = sentences;
    this.currentChunkIndex = 0;

    this.speakNextChunk(voiceName);
  }

  private speakNextChunk(voiceName?: string) {
    if (!this.synth || this.currentChunkIndex >= this.chunks.length) {
      this.state.isPlaying = false;
      this.state.isPaused = false;
      this.notify();
      return;
    }

    const chunk = this.chunks[this.currentChunkIndex];
    const utterance = new SpeechSynthesisUtterance(chunk);
    utterance.rate = this.state.rate;
    utterance.pitch = 1.0;

    if (voiceName) {
      const selected = this.voices.find((v) => v.name === voiceName);
      if (selected) utterance.voice = selected;
    } else {
      // Prefer standard clean English voice if available
      const preferred = this.voices.find(
        (v) => (v.lang.startsWith('en') && (v.name.includes('Natural') || v.name.includes('Samantha') || v.name.includes('Google')))
      );
      if (preferred) utterance.voice = preferred;
    }

    utterance.onend = () => {
      this.currentChunkIndex++;
      this.speakNextChunk(voiceName);
    };

    utterance.onerror = (e) => {
      console.warn('SpeechSynthesis error:', e);
      this.currentChunkIndex++;
      this.speakNextChunk(voiceName);
    };

    this.currentUtterance = utterance;
    this.synth.speak(utterance);
  }

  public pause() {
    if (!this.synth || !this.state.isPlaying) return;
    this.synth.pause();
    this.state.isPaused = true;
    this.notify();
  }

  public resume() {
    if (!this.synth || !this.state.isPaused) return;
    this.synth.resume();
    this.state.isPaused = false;
    this.notify();
  }

  public stop() {
    if (!this.synth) return;
    this.synth.cancel();
    this.chunks = [];
    this.currentChunkIndex = 0;
    this.currentUtterance = null;
    this.state.isPlaying = false;
    this.state.isPaused = false;
    this.notify();
  }
}

export const tts = new TTSService();
