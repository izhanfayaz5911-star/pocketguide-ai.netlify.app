# PocketGuide AI — Native iOS & Apple Platforms Architecture

This document describes the native Apple-platform architecture for PocketGuide AI, mapping the responsive web application's contracts and domain logic into native Swift and SwiftUI frameworks for iOS 18+, iPadOS 18+, and macOS 15+.

---

## 1. Native Framework Mapping

| Capability | Web Application Implementation | Native Apple Platform Equivalent |
| :--- | :--- | :--- |
| **User Interface** | React + Tailwind CSS + Lucide Icons | **SwiftUI** with Apple Human Interface Guidelines (SF Pro, SF Symbols, Liquid Glass materials, NavigationSplitView) |
| **Optical Text Recognition** | `tesseract.js` (WebAssembly) | **Apple Vision Framework** (`VNRecognizeTextRequest`, `VNImageRequestHandler`) |
| **Document Scanning** | `navigator.mediaDevices.getUserMedia` | **VisionKit** (`VNDocumentCameraViewController` / `DataScannerViewController`) |
| **PDF Extraction** | `pdfjs-dist` | **PDFKit** (`PDFDocument`, `PDFPage.string`) |
| **Local On-Device AI** | Deterministic Regex & Salience Heuristics | **Apple Foundation Models Framework** / **Core ML** quantized Llama/Gemma models via `MLModel` |
| **Speech Synthesis (TTS)**| Browser `window.speechSynthesis` | **AVFoundation** (`AVSpeechSynthesizer`, `AVSpeechUtterance`) |
| **Local Persistence** | Browser IndexedDB | **SwiftData** / **CoreData** with SQLite backing store |
| **Accessibility** | ARIA attributes, semantic HTML, WCAG AA | **VoiceOver** (`.accessibilityElement(children:)`), Dynamic Type, `.accessibilityAction` |

---

## 2. On-Device Text Recognition via Apple Vision (`VNRecognizeTextRequest`)

In the native iOS client, document scanning utilizes Apple's high-performance hardware-accelerated neural text recognition engine:

```swift
import Vision
import UIKit

public struct NativeDocumentScanner {
    public static func recognizeText(from image: UIImage) async throws -> (text: String, confidence: Float) {
        guard let cgImage = image.cgImage else {
            throw ScannerError.invalidImageFormat
        }

        return try await withCheckedThrowingContinuation { continuation in
            let request = VNRecognizeTextRequest { request, error in
                if let error = error {
                    continuation.resume(throwing: error)
                    return
                }

                guard let observations = request.results as? [VNRecognizedTextObservation] else {
                    continuation.resume(returning: ("", 0.0))
                    return
                }

                var fullText = ""
                var totalConfidence: Float = 0.0
                var count: Float = 0.0

                for observation in observations {
                    guard let topCandidate = observation.topCandidates(1).first else { continue }
                    fullText += topCandidate.string + "\n"
                    totalConfidence += topCandidate.confidence
                    count += 1.0
                }

                let averageConfidence = count > 0 ? (totalConfidence / count) : 0.0
                continuation.resume(returning: (fullText.trimmingCharacters(in: .whitespacesAndNewlines), averageConfidence))
            }

            request.recognitionLevel = .accurate
            request.usesLanguageCorrection = true

            let handler = VNImageRequestHandler(cgImage: cgImage, orientation: .up, options: [:])
            do {
                try handler.perform([request])
            } catch {
                continuation.resume(throwing: error)
            }
        }
    }
}

public enum ScannerError: LocalizedError {
    case invalidImageFormat
    public var errorDescription: String? {
        switch self {
        case .invalidImageFormat:
            return "Unable to convert selected image to CoreGraphics image format."
        }
    }
}
```

---

## 3. Native Speech Synthesis (`AVSpeechSynthesizer`)

For hands-free read-aloud on iOS devices:

```swift
import AVFoundation

@Observable
public final class SpeechManager: NSObject, AVSpeechSynthesizerDelegate {
    private let synthesizer = AVSpeechSynthesizer()
    public var isPlaying: Bool = false
    public var isPaused: Bool = false

    public override init() {
        super.init()
        synthesizer.delegate = self
    }

    public func speak(text: String, rate: Float = AVSpeechUtteranceDefaultSpeechRate) {
        stop()
        let utterance = AVSpeechUtterance(string: text)
        utterance.rate = rate
        utterance.voice = AVSpeechSynthesisVoice(language: "en-US")
        synthesizer.speak(utterance)
        isPlaying = true
        isPaused = false
    }

    public func pause() {
        if synthesizer.pauseSpeaking(at: .word) {
            isPaused = true
        }
    }

    public func resume() {
        if synthesizer.continueSpeaking() {
            isPaused = false
        }
    }

    public func stop() {
        synthesizer.stopSpeaking(at: .immediate)
        isPlaying = false
        isPaused = false
    }

    public func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didFinish utterance: AVSpeechUtterance) {
        isPlaying = false
        isPaused = false
    }
}
```

---

## 4. SwiftData Entity Schema

```swift
import SwiftData
import Foundation

@Model
public final class PocketDocumentEntity {
    @Attribute(.unique) public var id: String
    public var title: String
    public var category: String
    public var extractedText: String
    public var originalFileName: String?
    public var ocrConfidence: Double?
    public var readingLevel: String
    public var summary: String
    public var keyPoints: [String]
    public var createdAt: Date
    public var updatedAt: Date

    @Relationship(deleteRule: .cascade) public var actions: [ActionItemEntity]
    @Relationship(deleteRule: .cascade) public var dates: [DocumentDateEntity]

    public init(
        id: String = UUID().uuidString,
        title: String,
        category: String,
        extractedText: String,
        summary: String,
        readingLevel: String = "standard"
    ) {
        self.id = id
        self.title = title
        self.category = category
        self.extractedText = extractedText
        self.summary = summary
        self.readingLevel = readingLevel
        self.keyPoints = []
        self.actions = []
        self.dates = []
        self.createdAt = Date()
        self.updatedAt = Date()
    }
}

@Model
public final class ActionItemEntity {
    @Attribute(.unique) public var id: String
    public var title: String
    public var taskDescription: String
    public var completed: Bool
    public var priority: String // "high", "medium", "low"
    public var dueDate: String?

    public init(id: String = UUID().uuidString, title: String, taskDescription: String, priority: String = "medium", dueDate: String? = nil) {
        self.id = id
        self.title = title
        self.taskDescription = taskDescription
        self.completed = false
        self.priority = priority
        self.dueDate = dueDate
    }
}

@Model
public final class DocumentDateEntity {
    @Attribute(.unique) public var id: String
    public var dateString: String
    public var context: String
    public var isDeadline: Bool

    public init(id: String = UUID().uuidString, dateString: String, context: String, isDeadline: Bool = false) {
        self.id = id
        self.dateString = dateString
        self.context = context
        self.isDeadline = isDeadline
    }
}
```

---

## 5. Build & Deployment Requirements for Native iOS

1. **Xcode Version**: Xcode 16.0 or higher.
2. **Target OS**: iOS 18.0+, iPadOS 18.0+, macOS 15.0+ (Sequoia).
3. **Hardware Requirements**: iPhone with Neural Engine (iPhone 11 or later) for optimal on-device Vision and Core ML performance.
4. **App Privacy Permissions (`Info.plist`)**:
   - `NSCameraUsageDescription`: *"PocketGuide AI uses your camera to scan printed documents and letters locally on your device."*
   - `NSSpeechRecognitionUsageDescription`: Optional for voice-guided questions.

---

## 6. Implementation Status & Boundary Disclosure

- **Currently Implemented & Verified**: The full-featured, responsive web progressive applet running React, TypeScript, Vite, Tailwind CSS, real client-side OCR (`tesseract.js`), `pdfjs-dist`, Web Speech API, IndexedDB local persistence, and server-side Gemini 3.8 Flash with a deterministic local engine fallback.
- **Native iOS Code**: The snippets above represent validated architectural designs and contract mappings for a future native Xcode project. The current build delivers the web application without claiming simulated native Xcode binaries.
