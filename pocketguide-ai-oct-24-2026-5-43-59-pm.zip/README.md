# PocketGuide AI

> **Transform complex documents, notices, and fine print into plain-language explanations, audio briefings, and actionable checklists.**

PocketGuide AI is a privacy-conscious, local-first web application designed to help people understand complicated paperwork. Whether it's a school permission slip, a medical discharge care plan, a municipal compliance notice, or an appliance manual, PocketGuide AI extracts text using genuine OCR, translates bureaucratic jargon into clear reading levels, highlights critical deadlines, and turns requirements into actionable to-do lists.

---

## Key Features

1. **Document Ingestion & OCR**
   - **Camera Capture**: Live camera feed with document alignment guides and image rotation.
   - **Image OCR**: Real optical character recognition via Tesseract.js (runs 100% in-browser via WebAssembly).
   - **PDF Extraction**: Multi-page PDF parsing via PDF.js (`pdfjs-dist`).
   - **Extracted Text Editor**: Correct OCR typos or tweak text before generating explanations.
   - **Sample Library**: 4 pre-loaded realistic fictional documents for instant testing (School Excursion Notice, Surgical Care Plan, Municipal Water Notice, Induction Cooktop Manual).

2. **Plain-Language Document Workspace**
   - **Multi-Tier Reading Levels**: Switch dynamically between *Simple (5th-Grade)*, *Standard*, and *Detailed* explanations.
   - **Structured Information Extraction**: Key figures (fees, phone numbers, reference IDs, issuing organizations) linked to source snippets.
   - **Important Dates & Deadlines**: Automatically flags scheduled dates and impending deadlines.
   - **Grounded Q&A**: Answers user questions strictly using the document contents; clearly states when information is missing.
   - **Multilingual Translation**: Translates summaries into Spanish, French, German, Hindi, Mandarin, Arabic, Portuguese, Japanese, or Vietnamese.

3. **Task & Checklist Management**
   - Converts requirements into interactive to-do items.
   - Add custom tasks, assign due dates, and mark items as complete.
   - Export checklists as Markdown, plain text, or print formatted briefs.

4. **Speech & Accessibility**
   - **Text-to-Speech**: Hands-free playback using the browser's Web Speech API with pause, resume, and variable playback speeds (0.8x to 1.5x).
   - **Apple-Inspired Design**: Soft neutral surfaces, deep navy typography, zero-pill metadata discipline, WCAG AA contrast, and accessible focus states.

5. **Privacy & Security**
   - **Local-First Storage**: All documents, tasks, and history persist in browser IndexedDB.
   - **Consent-Driven AI**: Toggle to disable external AI calls and enforce 100% on-device deterministic processing.
   - **No Secrets in Frontend**: API keys are handled strictly by the server.

---

## Tech Stack

- **Frontend**: React 19, TypeScript, Vite, Tailwind CSS v4, Lucide Icons
- **Backend**: Node.js, Express, TypeScript (`tsx`), Zod for request validation
- **Document Processing**: Tesseract.js, PDF.js (`pdfjs-dist`)
- **AI Models**: Gemini 3.8 Flash (`@google/genai`) with deterministic local fallback
- **Audio**: Web Speech API (`SpeechSynthesis`)
- **Persistence**: IndexedDB (with LocalStorage fallback)

---

## Getting Started

### Prerequisites
- Node.js 18+ (tested on Node.js 20+)
- npm or pnpm

### Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Start the development server
npm run dev

# 3. Open in your browser
# Dev server runs at http://localhost:3000
```

### Running Automated Tests

```bash
npm test
```

### Building for Production

```bash
npm run build
npm start
```

---

## Environment Variables

Copy `.env.example` to `.env`:

```env
# Optional: Gemini API Key for server-side AI processing
# If omitted, PocketGuide AI operates with its deterministic local engine!
GEMINI_API_KEY=""

# Application URL
APP_URL="http://localhost:3000"
```

---

## Documentation

- [Devpost Hackathon Submission Package](HACKATHON_SUBMISSION.md)
- [Native Apple iOS Implementation Roadmap](ios/README.md)
