import { analyzeDocumentLocally, answerQuestionAboutDocument, answerQuestionLocally, isGeminiConfigured } from '../server/aiService';
import { SAMPLE_DOCUMENTS } from '../src/lib/sampleDocs';
import { ActionItem } from '../src/types/document';

let totalTests = 0;
let passedTests = 0;
let failedTests = 0;

function assert(condition: boolean, testName: string, details?: string) {
  totalTests++;
  if (condition) {
    passedTests++;
    console.log(`  ✓ PASS: ${testName}`);
  } else {
    failedTests++;
    console.error(`  ✗ FAIL: ${testName}${details ? ` -> ${details}` : ''}`);
  }
}

async function runTestSuite() {
  console.log('\n========================================');
  console.log('  RUNNING POCKETGUIDE AI TEST SUITE     ');
  console.log('========================================\n');

  // Test 1: Sample Documents Integrity
  console.log('Test Suite 1: Sample Documents Library');
  assert(SAMPLE_DOCUMENTS.length === 4, 'All 4 sample test documents are loaded');
  SAMPLE_DOCUMENTS.forEach((doc) => {
    assert(doc.title.length > 5, `Doc "${doc.id}" has valid title`);
    assert(doc.extractedText.length > 100, `Doc "${doc.id}" has realistic document text`);
    assert(!!doc.category, `Doc "${doc.id}" has assigned category`);
  });

  // Test 2: Local Rule-Based Document Analysis
  console.log('\nTest Suite 2: Local Deterministic Document Analyzer');
  const schoolDoc = SAMPLE_DOCUMENTS[0];
  const analysis = analyzeDocumentLocally(schoolDoc.extractedText, 'standard');

  assert(analysis.isLocalFallback === true, 'Analysis honestly flags local processing');
  assert(analysis.summary.length > 20, 'Summary was generated');
  assert(analysis.dates.length >= 2, `Dates were extracted (found ${analysis.dates.length})`);
  assert(analysis.dates.some((d) => d.date.includes('November')), 'Extracted November dates');
  assert(analysis.dates.some((d) => d.isDeadline), 'Identified deadline in date list');
  assert(analysis.actions.length >= 2, `Extracted action items (found ${analysis.actions.length})`);
  assert(analysis.keyInfo.some((k) => k.category === 'Amount' || k.value.includes('$')), 'Extracted financial fee ($42.00)');

  // Test 3: Reading Levels (Simple vs Detailed)
  console.log('\nTest Suite 3: Multi-Tier Reading Level Synthesis');
  const simpleAnalysis = analyzeDocumentLocally(schoolDoc.extractedText, 'simple');
  const detailedAnalysis = analyzeDocumentLocally(schoolDoc.extractedText, 'detailed');
  assert(simpleAnalysis.readingLevel === 'simple', 'Simple reading level preserved');
  assert(detailedAnalysis.readingLevel === 'detailed', 'Detailed reading level preserved');
  assert(detailedAnalysis.summary.length >= simpleAnalysis.summary.length, 'Detailed summary is comprehensive');

  // Test 4: Grounded Document Q&A
  console.log('\nTest Suite 4: Grounded Document Q&A');
  const questionAnswered = answerQuestionLocally(
    schoolDoc.extractedText,
    'What is the trip fee per student?'
  );
  assert(questionAnswered.isFound === true, 'Answer found for fee question');
  assert(questionAnswered.answer.includes('$42') || questionAnswered.answer.includes('Fee'), 'Answer accurately references fee info');

  const questionMissing = answerQuestionLocally(
    schoolDoc.extractedText,
    'What is the capital of Mars?'
  );
  assert(questionMissing.isFound === false, 'Accurately marks non-existent information as not found');
  assert(
    questionMissing.answer.toLowerCase().includes('not appear') ||
    questionMissing.answer.toLowerCase().includes('not stated') ||
    questionMissing.answer.toLowerCase().includes('not found'),
    'Honest disclosure when facts are missing from document'
  );

  // Test 5: Checklist State Management & Markdown Export
  console.log('\nTest Suite 5: Action Checklist Mutations & Export');
  const initialActions: ActionItem[] = [
    { id: '1', title: 'Sign permission waiver', description: 'Return signed section B', completed: false, priority: 'high', dueDate: 'Nov 7' },
    { id: '2', title: 'Pack sack lunch', description: 'No glass containers', completed: false, priority: 'medium' },
  ];

  // Toggle complete
  const toggled = initialActions.map((a) => (a.id === '1' ? { ...a, completed: true } : a));
  assert(toggled.find((a) => a.id === '1')?.completed === true, 'Task completed state toggles');
  assert(toggled.find((a) => a.id === '2')?.completed === false, 'Other task remains pending');

  // Add custom task
  const withNewTask: ActionItem[] = [
    ...toggled,
    { id: '3', title: 'Notify nurse', description: 'Form 4-B', completed: false, priority: 'high', dueDate: 'Nov 5' },
  ];
  assert(withNewTask.length === 3, 'New task added to list');

  // Markdown export formatting
  const exportLines = withNewTask.map((a) => `[${a.completed ? 'x' : ' '}] ${a.title}${a.dueDate ? ` (Due: ${a.dueDate})` : ''}`);
  assert(exportLines[0] === '[x] Sign permission waiver (Due: Nov 7)', 'Markdown task checked formatting');
  assert(exportLines[1] === '[ ] Pack sack lunch', 'Markdown task unchecked formatting');

  // Test 6: Malformed Input Safety
  console.log('\nTest Suite 6: Input Validation & Edge Cases');
  try {
    const emptyResult = analyzeDocumentLocally('', 'standard');
    assert(emptyResult.summary !== undefined, 'Empty text handled gracefully without crashing');
    assert(emptyResult.actions.length === 0, 'No false actions on empty document');
  } catch (err) {
    assert(false, 'Analyzer threw unhandled exception on empty string');
  }

  // Summary
  console.log('\n========================================');
  console.log(`TEST RESULTS: ${passedTests}/${totalTests} PASSED`);
  if (failedTests > 0) {
    console.log(`FAILED: ${failedTests}`);
    process.exit(1);
  } else {
    console.log('ALL TESTS COMPLETED SUCCESSFULLY! ✓');
    console.log('========================================\n');
  }
}

runTestSuite().catch((e) => {
  console.error('Test runner fatal error:', e);
  process.exit(1);
});
