# Devpost Hackathon Submission: PocketGuide AI

## Project Name
**PocketGuide AI**

## Concise Tagline
*Transform complex documents, notices, and fine print into plain-language explanations, audio briefings, and actionable checklists.*

---

## 1. Problem Statement
Every day, millions of people receive intimidating documents:
- Parents receive school excursion notices with convoluted liability waivers, strict medical deadlines, and payment rules.
- Patients leaving the hospital receive multi-page surgical discharge summaries filled with medical jargon, contraindications, and complex medication timings.
- Homeowners and small businesses receive municipal compliance orders and utility inspection demands threatening penalties and shutoffs.
- Consumers struggle to decipher technical installation manuals and appliance error codes.

For non-native speakers, elderly citizens, neurodivergent individuals, or busy families, dense bureaucratic text causes missed deadlines, financial penalties, medication errors, and anxiety.

---

## 2. Solution Description
**PocketGuide AI** is an Apple-inspired document accessibility assistant that simplifies complicated documents:
1. **Real Document Processing**: Users can scan physical documents with their device camera, upload photos, or drag-and-drop multi-page PDFs. Text is extracted using genuine in-browser OCR (`tesseract.js`) and `pdfjs-dist`.
2. **Plain-Language Synthesis**: Synthesizes the text into three customizable reading tiers: *Simple (5th-grade)*, *Standard*, or *Detailed*, without jargon.
3. **Structured Entity & Date Extraction**: Automatically extracts critical figures, reference IDs, contact numbers, and scheduled deadlines.
4. **Interactive Action Checklists**: Converts requirements directly into editable to-dos with priority badges, optional due dates, and export capabilities.
5. **Grounded Q&A**: Answers questions strictly using source text, with direct quotation of source passages and honest "Not found in document" disclosures.
6. **Hands-Free Text-to-Speech**: Integrated browser speech synthesis with variable playback rates and pause/resume controls.
7. **Local-First Privacy**: Guest mode works immediately without requiring account creation. All documents and checklists persist in browser IndexedDB.

---

## 3. Community Impact Track Rationale
PocketGuide AI directly promotes digital equity, accessibility, and public understanding:
- **Zero Cost (₹0 Budget)**: Completely functional using free and open-source software with zero mandatory paywalls or subscriptions.
- **Multilingual Support**: Real-time translation of summaries into Spanish, French, German, Hindi, Mandarin, Arabic, Portuguese, Japanese, and Vietnamese.
- **Neurodivergent & Low-Literacy Friendly**: Reading level controls allow users with cognitive challenges or English language learners to digest notices at a comfortable level.
- **Auditory Accessibility**: Complete Web Speech text-to-speech support for visually impaired users.
- **Transparent Boundaries**: PocketGuide AI explicitly states that it is an understanding aid, not a substitute for legal, medical, or government counsel.

---

## 4. Technology Stack
- **Frontend**: React 19, TypeScript, Vite, Tailwind CSS v4, Lucide Icons.
- **Backend**: Node.js, Express, TypeScript (`tsx`), Zod for request schema validation.
- **Document Processing**: Tesseract.js (WebAssembly OCR), PDF.js (`pdfjs-dist`).
- **AI & Language Processing**: Gemini 3.8 Flash (`@google/genai`) with server-side proxy; deterministic rule-based local fallback engine for offline or zero-credential environments.
- **Speech Synthesis**: Browser Web Speech API (`SpeechSynthesis`).
- **Storage**: IndexedDB with LocalStorage fallback.

---

## 5. Explanation of Genuine AI Usage
- **Server-Side Gemini Integration**: Calls the `gemini-3.8-flash` model using the official `@google/genai` TypeScript SDK on the server, enforcing structured JSON schemas (`Type.OBJECT`, `Type.ARRAY`).
- **Hallucination Protection**: Prompts enforce strict grounding in source passages. If a user asks a question whose answer is absent from the document, the system explicitly declares that the fact is not mentioned.
- **Graceful Deterministic Fallback**: When an API key is not present or if network calls fail, PocketGuide AI smoothly switches to its deterministic local engine (regex date extractors, salience heuristics, and imperative verb analyzers) and displays an honest "Deterministic Local Engine" indicator.

---

## 6. Privacy & Security Approach
- **No Client Secret Exposure**: API credentials are kept exclusively on the server (`process.env.GEMINI_API_KEY`).
- **Camera Images Stay On-Device**: Camera frames and OCR processing occur entirely within the browser sandbox via WebAssembly.
- **Explicit Consent**: A privacy toggle allows users to disable external AI calls, restricting the app entirely to local on-device heuristics.
- **Data Portability**: Users can export their entire document and checklist history as a JSON file or wipe their local data with a single click.

---

## 7. Installation & Quick Start

```bash
# 1. Clone repository & install dependencies
npm install

# 2. Configure environment (optional: inject your Gemini API key)
# Note: The app runs 100% locally even without an API key using its deterministic engine!
cp .env.example .env

# 3. Start development server
npm run dev

# 4. Run automated test suite
npm test

# 5. Build for production
npm run build
npm start
```

---

## 8. Guided Demo Script
1. **Explore the Dashboard**: Note the clean, Apple-inspired layout, zero-pill typography, and quick metrics strip.
2. **Try a 1-Click Sample**: Click *"Try Sample School Notice"* on the dashboard.
3. **Inspect the 7-Tab Workspace**:
   - Tab 1: Read the Plain Summary. Switch the reading level toggle from *Standard* to *Simple* to see simplified phrasing.
   - Tab 2: View Key Information (Trip fee of $42.00, contact numbers, case IDs).
   - Tab 3: Inspect Important Dates (Departure time, deadline of Friday, Nov 7).
   - Tab 4 & 5: Check off completed items in the Action Checklist, add a custom task, and click "Export" to copy the checklist as Markdown.
   - Tab 6: In *Ask Document*, type: *"When is the permission slip due?"* Observe the direct citation. Then ask *"What is the weather on Mars?"* to observe honest missing-information disclosure.
   - Tab 7: Inspect the raw source text side-by-side.
4. **Listen Aloud**: Click *"Read Aloud"* in the top audio bar to test Web Speech synthesis. Adjust speed to 1.25x.
5. **Scan a Real Document**: Click *"New Document"*, open the camera guide or upload a PDF/photo, watch the real-time OCR progress, edit any typos, and generate insights.

---

## 9. Suggested Screenshots for Devpost
1. `01_dashboard.png`: Apple-inspired dashboard showing greeting, quick actions, and recent documents.
2. `02_workspace_summary.png`: Document explanation workspace showing reading level switcher and audio read-aloud bar.
3. `03_checklist_manager.png`: Interactive action items checklist with completion progress and urgent tags.
4. `04_camera_scanner.png`: Live camera capture view with alignment grid.
5. `05_privacy_settings.png`: Privacy architecture modal with processing breakdown and data export.

---

## 10. Known Limitations
- High-resolution multi-page PDF OCR on mobile phones may require several seconds of CPU processing depending on device memory.
- Browser SpeechSynthesis voice availability varies by operating system (macOS/iOS provide Siri and Samantha; Windows provides Microsoft David/Zira; Android provides Google TTS).
- The current implementation delivers a full web application; a native Swift/SwiftUI iOS build is detailed in `ios/README.md` as an upcoming roadmap milestone.
