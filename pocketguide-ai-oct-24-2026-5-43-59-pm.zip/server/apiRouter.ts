import express, { Request, Response, NextFunction } from 'express';
import { z } from 'zod';
import {
  isGeminiConfigured,
  summarizeAndAnalyzeDocument,
  answerQuestionAboutDocument,
  translateDocumentExplanation,
} from './aiService';

export const apiRouter = express.Router();

// Health Check
apiRouter.get('/health', (_req: Request, res: Response) => {
  res.json({
    status: 'ok',
    hasGeminiKey: isGeminiConfigured(),
    model: isGeminiConfigured() ? 'gemini-3.8-flash' : 'local-deterministic-engine',
    localFallbackActive: !isGeminiConfigured(),
    timestamp: new Date().toISOString(),
  });
});

// Zod schemas for input validation
const AnalyzeSchema = z.object({
  text: z.string().min(5, 'Text must be at least 5 characters').max(100000, 'Text exceeds maximum length of 100k characters'),
  readingLevel: z.enum(['simple', 'standard', 'detailed']).optional().default('standard'),
});

const QASchema = z.object({
  text: z.string().min(5, 'Text must be at least 5 characters').max(100000, 'Text exceeds 100k characters'),
  question: z.string().min(2, 'Question is too short').max(500, 'Question too long'),
});

const TranslateSchema = z.object({
  text: z.string().min(1).max(50000),
  targetLanguage: z.string().min(2).max(60),
});

// Document Analysis Endpoint
apiRouter.post('/ai/analyze', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const parseResult = AnalyzeSchema.safeParse(req.body);
    if (!parseResult.success) {
      return res.status(400).json({
        error: 'Validation Error',
        details: parseResult.error.flatten().fieldErrors,
      });
    }

    const { text, readingLevel } = parseResult.data;
    const analysis = await summarizeAndAnalyzeDocument(text, readingLevel);
    res.json(analysis);
  } catch (error: any) {
    next(error);
  }
});

// Document Grounded Q&A Endpoint
apiRouter.post('/ai/qa', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const parseResult = QASchema.safeParse(req.body);
    if (!parseResult.success) {
      return res.status(400).json({
        error: 'Validation Error',
        details: parseResult.error.flatten().fieldErrors,
      });
    }

    const { text, question } = parseResult.data;
    const qa = await answerQuestionAboutDocument(text, question);
    res.json(qa);
  } catch (error: any) {
    next(error);
  }
});

// Translation Endpoint
apiRouter.post('/ai/translate', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const parseResult = TranslateSchema.safeParse(req.body);
    if (!parseResult.success) {
      return res.status(400).json({
        error: 'Validation Error',
        details: parseResult.error.flatten().fieldErrors,
      });
    }

    const { text, targetLanguage } = parseResult.data;
    const result = await translateDocumentExplanation(text, targetLanguage);
    res.json(result);
  } catch (error: any) {
    next(error);
  }
});

// Error handling middleware
apiRouter.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
  console.error('API Error:', err);
  res.status(500).json({
    error: 'Internal Server Error',
    message: err.message || 'An unexpected error occurred during processing',
  });
});

/**
 * Helper to handle requests inside Vite dev server middleware
 */
const expressApp = express();
expressApp.use(express.json({ limit: '10mb' }));
expressApp.use(express.urlencoded({ extended: true, limit: '10mb' }));
expressApp.use('/', apiRouter);

export function handleApiRequest(req: any, res: any, next: any) {
  expressApp(req, res, next);
}
