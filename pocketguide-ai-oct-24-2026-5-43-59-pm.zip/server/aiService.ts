import { GoogleGenAI, Type } from '@google/genai';
import { ReadingLevel, DocumentAnalysis, QAExchange, KeyInformationItem, DocumentDateItem, ActionItem } from '../src/types/document';

const apiKey = process.env.GEMINI_API_KEY;
const ai = apiKey
  ? new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    })
  : null;

/**
 * Check if the Gemini API key is configured on the server
 */
export function isGeminiConfigured(): boolean {
  return !!ai;
}

/**
 * Local Rule-Based Fallback Document Analyzer
 * Provides real, deterministic document understanding without relying on external APIs.
 */
export function analyzeDocumentLocally(text: string, readingLevel: ReadingLevel = 'standard'): DocumentAnalysis {
  const lines = text.split('\n').map(l => l.trim()).filter(Boolean);
  const sentences = text
    .replace(/([.?!])\s+/g, '$1|')
    .split('|')
    .map(s => s.trim())
    .filter(s => s.length > 5);

  // 1. Extract Dates
  const dateRegex = /\b(?:(?:Mon|Tues|Wednes|Thurs|Fri|Satur|Sun)day,?\s+)?(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)\s+\d{1,2}(?:st|nd|rd|th)?,?\s+\d{4}|\b\d{1,2}[\/\-.]\d{1,2}[\/\-.]\d{2,4}\b/gi;
  const dates: DocumentDateItem[] = [];
  const foundDateStrings = new Set<string>();

  for (const sentence of sentences) {
    const matches = sentence.match(dateRegex);
    if (matches) {
      for (const m of matches) {
        if (!foundDateStrings.has(m.toLowerCase())) {
          foundDateStrings.add(m.toLowerCase());
          const isDeadline = /deadline|due|by|before|no later than|prior to|schedule|scheduled|expires|past due/i.test(sentence);
          dates.push({
            id: `date-${dates.length + 1}`,
            date: m,
            context: sentence.slice(0, 160),
            isDeadline,
            sourceSnippet: sentence.slice(0, 200),
            isUncertain: false,
          });
        }
      }
    }
  }

  // 2. Extract Key Information (Amounts, Reference IDs, Phones, Emails, Organizations)
  const keyInfo: KeyInformationItem[] = [];

  // Amounts
  const amountRegex = /\$\s?\d{1,3}(?:,\d{3})*(?:\.\d{2})?/g;
  const amounts = text.match(amountRegex);
  if (amounts) {
    const uniqueAmounts = Array.from(new Set(amounts));
    uniqueAmounts.slice(0, 3).forEach((amt, idx) => {
      const sentence = sentences.find(s => s.includes(amt)) || '';
      keyInfo.push({
        id: `info-amt-${idx}`,
        label: 'Financial Amount',
        value: amt,
        category: 'Amount',
        sourceSnippet: sentence.slice(0, 160),
      });
    });
  }

  // Reference IDs / Account Numbers
  const refRegex = /(?:Account|Ref|Reference|Case|Model|MRN|Serial)\s*(?:Number|ID|#)?[:.\s]+([A-Z0-9\-#]+)/gi;
  let refMatch: RegExpExecArray | null;
  let refCount = 0;
  while ((refMatch = refRegex.exec(text)) !== null && refCount < 3) {
    keyInfo.push({
      id: `info-ref-${refCount}`,
      label: 'Reference Identifier',
      value: refMatch[0].trim(),
      category: 'Reference ID',
      sourceSnippet: refMatch[0],
    });
    refCount++;
  }

  // Phone numbers
  const phoneRegex = /(?:\+?1[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}/g;
  const phones = text.match(phoneRegex);
  if (phones) {
    const uniquePhones = Array.from(new Set(phones));
    uniquePhones.slice(0, 2).forEach((phone, idx) => {
      const sentence = sentences.find(s => s.includes(phone)) || '';
      keyInfo.push({
        id: `info-phone-${idx}`,
        label: 'Contact Phone',
        value: phone,
        category: 'Organization',
        sourceSnippet: sentence.slice(0, 160),
      });
    });
  }

  // Header / Entity
  if (lines.length > 0) {
    keyInfo.unshift({
      id: 'info-issuer',
      label: 'Issuing Organization',
      value: lines[0].replace(/[#*_-]/g, '').trim(),
      category: 'Organization',
      sourceSnippet: lines[0],
    });
  }

  // 3. Extract Actions
  const actions: ActionItem[] = [];
  const actionVerbsRegex = /^(?:1\.|2\.|3\.|4\.|5\.|[-*•])?\s*(?:submit|sign|return|pay|complete|provide|bring|keep|avoid|refrain|call|contact|schedule|apply|clean|turn off|do not|ensure|review)\b/i;

  for (const sentence of sentences) {
    if (actionVerbsRegex.test(sentence) || /action required|mandatory|must|required to|should be/i.test(sentence)) {
      if (actions.length < 8) {
        const cleanTitle = sentence.replace(/^[-*•\d.]+\s*/, '').slice(0, 80);
        const isHigh = /urgent|immediate|mandatory|penalty|must|past due|no later than/i.test(sentence);
        actions.push({
          id: `action-${actions.length + 1}`,
          title: cleanTitle,
          description: sentence,
          completed: false,
          priority: isHigh ? 'high' : 'medium',
          sourceSnippet: sentence.slice(0, 200),
        });
      }
    }
  }

  // 4. Build Plain Summary according to reading level
  let summary = '';
  const firstFew = sentences.slice(0, 3).join(' ');
  const keyPoints: string[] = [];

  if (readingLevel === 'simple') {
    summary = `This document is from ${lines[0] || 'an organization'}. In short: ${firstFew.slice(0, 240)}. There are ${actions.length} main thing(s) to do and ${dates.length} date(s) to know.`;
  } else if (readingLevel === 'detailed') {
    summary = `Official notice regarding: ${lines.slice(0, 2).join(' - ')}. Summary of provisions: ${firstFew}. The document sets forth ${actions.length} explicit obligations, administrative protocols, and ${dates.length} scheduled milestones.`;
  } else {
    summary = `This document outlines key instructions and requirements from ${lines[0] || 'the sender'}. ${firstFew.slice(0, 300)}`;
  }

  if (actions.length > 0) {
    keyPoints.push(`Primary required action: ${actions[0].title}`);
  }
  if (dates.length > 0) {
    keyPoints.push(`Key deadline or date: ${dates[0].date} (${dates[0].context.slice(0, 60)})`);
  }
  if (keyInfo.length > 0) {
    keyPoints.push(`Primary reference: ${keyInfo[0].label} - ${keyInfo[0].value}`);
  }

  return {
    readingLevel,
    summary,
    keyPoints,
    keyInfo,
    dates,
    actions,
    isLocalFallback: true,
    analyzedAt: Date.now(),
  };
}

/**
 * Perform AI analysis using Gemini 3.8 Flash, or smoothly fall back to local rule-based analysis.
 */
export async function summarizeAndAnalyzeDocument(
  text: string,
  readingLevel: ReadingLevel = 'standard'
): Promise<DocumentAnalysis> {
  // If no Gemini API key configured, use local processing immediately
  if (!ai) {
    return analyzeDocumentLocally(text, readingLevel);
  }

  try {
    const readingInstruction =
      readingLevel === 'simple'
        ? 'Explain in 5th-grade plain English using very simple words, short sentences, and avoiding jargon.'
        : readingLevel === 'detailed'
        ? 'Provide a thorough, comprehensive breakdown detailing nuances, caveats, requirements, and fine print.'
        : 'Provide a clear, balanced explanation in everyday standard English.';

    const systemInstruction = `You are PocketGuide AI, a helpful, unbiased document-understanding assistant.
Your mission is to read documents (such as school notices, medical care instructions, utility bills, legal notices, or manuals) and translate complicated bureaucratic language into plain, actionable clarity.
Rules:
1. Ground every claim directly in the provided text. Never invent missing facts, deadlines, or fees.
2. Mark any uncertain information clearly.
3. If an answer or detail is not present in the document, state that it is not provided.
4. Reading Level: ${readingInstruction}
5. Return strictly valid JSON adhering to the provided schema.`;

    const prompt = `Analyze the following document text and extract structured insights.

DOCUMENT TEXT:
"""
${text.slice(0, 25000)}
"""`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        systemInstruction,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            summary: {
              type: Type.STRING,
              description: 'Plain-language summary of what this document is about and what it means for the reader.',
            },
            keyPoints: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: '3 to 5 core takeaway bullet points.',
            },
            keyInfo: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  label: { type: Type.STRING },
                  value: { type: Type.STRING },
                  category: { type: Type.STRING, description: 'Person, Organization, Amount, Reference ID, Requirement, or Other' },
                  sourceSnippet: { type: Type.STRING, description: 'Exact quote or source clause from the document' },
                  isUncertain: { type: Type.BOOLEAN },
                },
                required: ['label', 'value'],
              },
            },
            dates: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  date: { type: Type.STRING },
                  context: { type: Type.STRING },
                  isDeadline: { type: Type.BOOLEAN },
                  sourceSnippet: { type: Type.STRING },
                  isUncertain: { type: Type.BOOLEAN },
                },
                required: ['date', 'context', 'isDeadline'],
              },
            },
            actions: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  title: { type: Type.STRING },
                  description: { type: Type.STRING },
                  priority: { type: Type.STRING, description: 'high, medium, or low' },
                  dueDate: { type: Type.STRING },
                  sourceSnippet: { type: Type.STRING },
                },
                required: ['title', 'description', 'priority'],
              },
            },
          },
          required: ['summary', 'keyPoints', 'keyInfo', 'dates', 'actions'],
        },
      },
    });

    const rawJson = response.text?.trim();
    if (!rawJson) {
      throw new Error('Empty response from model');
    }

    const parsed = JSON.parse(rawJson);

    return {
      readingLevel,
      summary: parsed.summary,
      keyPoints: parsed.keyPoints || [],
      keyInfo: (parsed.keyInfo || []).map((item: any, idx: number) => ({
        id: `ai-info-${idx}`,
        ...item,
      })),
      dates: (parsed.dates || []).map((d: any, idx: number) => ({
        id: `ai-date-${idx}`,
        ...d,
      })),
      actions: (parsed.actions || []).map((a: any, idx: number) => ({
        id: `ai-action-${idx}`,
        completed: false,
        priority: a.priority === 'high' || a.priority === 'low' ? a.priority : 'medium',
        ...a,
      })),
      isLocalFallback: false,
      analyzedAt: Date.now(),
    };
  } catch (error) {
    console.warn('Gemini API call encountered error; falling back to local analysis:', error);
    return analyzeDocumentLocally(text, readingLevel);
  }
}

export function answerQuestionLocally(text: string, question: string): QAExchange {
  const sentences = text
    .replace(/([.?!])\s+/g, '$1|')
    .split('|')
    .map(s => s.trim())
    .filter(s => s.length > 5);

  const STOP_WORDS = new Set(['what', 'when', 'where', 'which', 'who', 'whom', 'this', 'that', 'these', 'those', 'the', 'and', 'for', 'with', 'about', 'from', 'have', 'has', 'had', 'are', 'was', 'were', 'been', 'being', 'how', 'does', 'did', 'will', 'can', 'could', 'should', 'would']);
  const queryWords = question
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, '')
    .split(/\s+/)
    .filter(w => w.length > 2 && !STOP_WORDS.has(w));

  let bestSentence = '';
  let highestScore = 0;

  if (queryWords.length > 0) {
    for (const s of sentences) {
      const lower = s.toLowerCase();
      let matchCount = 0;
      for (const qw of queryWords) {
        if (lower.includes(qw)) matchCount++;
      }
      if (matchCount > highestScore) {
        highestScore = matchCount;
        bestSentence = s;
      }
    }
  }

  if (highestScore > 0 && bestSentence) {
    return {
      id: `qa-${Date.now()}`,
      question,
      answer: `Based on the document text: "${bestSentence}"`,
      sourcePassage: bestSentence,
      isFound: true,
      timestamp: Date.now(),
    };
  } else {
    return {
      id: `qa-${Date.now()}`,
      question,
      answer: "This question does not appear to be answered in the extracted document text.",
      isFound: false,
      timestamp: Date.now(),
    };
  }
}

/**
 * Answer a question strictly grounded in the extracted document text.
 */
export async function answerQuestionAboutDocument(
  text: string,
  question: string
): Promise<QAExchange> {
  // If no Gemini key, do local keyword/sentence search
  if (!ai) {
    return answerQuestionLocally(text, question);
  }

  try {
    const prompt = `You are PocketGuide AI. Answer the user's question STRICTLY based on the provided document text.
Do NOT extrapolate, hallucinate, or assume facts not present in the document.
If the text does NOT contain the answer, explicitly state: "This information is not stated in the document."

DOCUMENT TEXT:
"""
${text.slice(0, 20000)}
"""

QUESTION:
${question}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            answer: { type: Type.STRING },
            sourcePassage: { type: Type.STRING, description: 'Direct excerpt from the text that answers the question, or empty string if not found' },
            isFound: { type: Type.BOOLEAN, description: 'Whether the answer is genuinely present in the document' },
          },
          required: ['answer', 'isFound'],
        },
      },
    });

    const parsed = JSON.parse(response.text?.trim() || '{}');
    return {
      id: `qa-${Date.now()}`,
      question,
      answer: parsed.answer || 'No answer available.',
      sourcePassage: parsed.sourcePassage || undefined,
      isFound: !!parsed.isFound,
      timestamp: Date.now(),
    };
  } catch (error) {
    console.warn('Q&A Gemini call encountered error; falling back to local text search:', error);
    return answerQuestionLocally(text, question);
  }
}

/**
 * Translate explanation text into target language
 */
export async function translateDocumentExplanation(
  text: string,
  targetLanguage: string
): Promise<{ translatedText: string; isLocalFallback: boolean }> {
  if (!ai) {
    return {
      translatedText: `[Translation to ${targetLanguage} requires Gemini API connection]:\n\n${text}`,
      isLocalFallback: true,
    };
  }

  try {
    const prompt = `Translate the following document summary into natural, accessible ${targetLanguage}.
Maintain clear, simple phrasing suitable for general readers.

TEXT TO TRANSLATE:
"""
${text}
"""`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
    });

    return {
      translatedText: response.text?.trim() || text,
      isLocalFallback: false,
    };
  } catch (error) {
    console.error('Translation error:', error);
    return {
      translatedText: text,
      isLocalFallback: true,
    };
  }
}
